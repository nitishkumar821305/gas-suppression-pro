package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.components.AppBottomNavigationBar
import com.example.ui.components.AppNavigationRail
import com.example.ui.navigation.Screen
import com.example.ui.screens.*
import com.example.ui.theme.GasSuppressionTheme
import com.example.ui.viewmodel.GasSuppressionViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            GasSuppressionTheme {
                val viewModel: GasSuppressionViewModel = viewModel()
                val navController = rememberNavController()

                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentRoute = navBackStackEntry?.destination?.route ?: Screen.Dashboard.route

                val configuration = LocalConfiguration.current
                val isWideScreen = configuration.screenWidthDp >= 600

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        if (!isWideScreen) {
                            AppBottomNavigationBar(
                                currentRoute = currentRoute,
                                onNavigate = { route ->
                                    navController.navigate(route) {
                                        popUpTo(Screen.Dashboard.route) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            )
                        }
                    }
                ) { innerPadding ->
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        if (isWideScreen) {
                            AppNavigationRail(
                                currentRoute = currentRoute,
                                onNavigate = { route ->
                                    navController.navigate(route) {
                                        popUpTo(Screen.Dashboard.route) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            )
                        }

                        Box(modifier = Modifier.weight(1f)) {
                            NavHost(
                                navController = navController,
                                startDestination = Screen.Dashboard.route
                            ) {
                                composable(Screen.Dashboard.route) {
                                    DashboardScreen(
                                        viewModel = viewModel,
                                        onNavigate = { route -> navController.navigate(route) }
                                    )
                                }
                                composable(Screen.Projects.route) {
                                    ProjectsScreen(
                                        viewModel = viewModel,
                                        onNavigate = { route -> navController.navigate(route) }
                                    )
                                }
                                composable(Screen.ProjectDetail.route) {
                                    ProjectDetailScreen(
                                        viewModel = viewModel,
                                        onNavigate = { route -> navController.navigate(route) }
                                    )
                                }
                                composable(Screen.RoomEditor.route) {
                                    RoomEditorScreen(
                                        viewModel = viewModel,
                                        onNavigate = { route -> navController.navigate(route) }
                                    )
                                }
                                composable(Screen.DesignCalculation.route) {
                                    DesignCalculationScreen(
                                        viewModel = viewModel,
                                        onNavigate = { route -> navController.navigate(route) }
                                    )
                                }
                                composable(Screen.Boq.route) {
                                    BoqScreen(
                                        viewModel = viewModel,
                                        onNavigate = { route -> navController.navigate(route) }
                                    )
                                }
                                composable(Screen.ExcelMapping.route) {
                                    ExcelReferenceMappingScreen(
                                        onNavigate = { route -> navController.navigate(route) }
                                    )
                                }
                                composable(Screen.Reports.route) {
                                    ReportsScreen(
                                        viewModel = viewModel,
                                        onNavigate = { route -> navController.navigate(route) }
                                    )
                                }
                                composable(Screen.Settings.route) {
                                    SettingsScreen(
                                        viewModel = viewModel,
                                        onNavigate = { route -> navController.navigate(route) }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
