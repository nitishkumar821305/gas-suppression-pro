package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.BoqItemEntity
import com.example.data.model.ProjectEntity
import com.example.data.model.RoomEntity
import com.example.data.model.SettingsEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        ProjectEntity::class,
        RoomEntity::class,
        BoqItemEntity::class,
        SettingsEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun projectDao(): ProjectDao
    abstract fun roomDao(): RoomDao
    abstract fun boqDao(): BoqDao
    abstract fun settingsDao(): SettingsDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "gas_suppression_db"
                )
                .addCallback(object : RoomDatabase.Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        // Seed default settings and sample project
                        INSTANCE?.let { database ->
                            CoroutineScope(Dispatchers.IO).launch {
                                database.settingsDao().saveSettings(SettingsEntity())
                                seedSampleData(database)
                            }
                        }
                    }
                })
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }

        private suspend fun seedSampleData(db: AppDatabase) {
            val projId = db.projectDao().insertProject(
                ProjectEntity(
                    projectCode = "PRJ-2026-001",
                    projectName = "Metro Data Center Fire Protection",
                    client = "Global Data Corp",
                    consultant = "Apex Engineering Solutions",
                    contractor = "FireSafe Systems Ltd",
                    location = "Tech Park, Building A",
                    projectNumber = "FO-2026-99",
                    revision = "R2",
                    date = "2026-02-20",
                    preparedBy = "Lead Design Engineer",
                    checkedBy = "Chief Technical Officer",
                    approvedBy = "Project Director",
                    remarks = "High reliability gas suppression system per NFPA standards."
                )
            )

            // Room 1: Control Room (CO2)
            db.roomDao().insertRoom(
                RoomEntity(
                    projectId = projId,
                    roomName = "MAIN CONTROL ROOM",
                    systemType = "CO2",
                    length = 10.0,
                    width = 8.0,
                    height = 4.0,
                    unit = "metre",
                    hazardType = "Electrical",
                    designConcentration = 50.0,
                    temperature = 20.0,
                    cylinderCapacity = 45.0,
                    remarks = "Main control center with electrical cabinets"
                )
            )

            // Room 2: IG-541 Battery Room
            db.roomDao().insertRoom(
                RoomEntity(
                    projectId = projId,
                    roomName = "BATTERY ROOM",
                    systemType = "IG541",
                    length = 12.0,
                    width = 6.0,
                    height = 3.5,
                    unit = "metre",
                    hazardType = "Surface",
                    designConcentration = 38.0,
                    temperature = 20.0,
                    cylinderCapacity = 15.2,
                    cylinderPressure = 200,
                    cylinderVolumeLiters = 80.0,
                    remarks = "Inergen clean agent suppression"
                )
            )
        }
    }
}
