package com.example.data.repository

import com.example.calculations.BOQEngine
import com.example.data.db.AppDatabase
import com.example.data.model.BoqItemEntity
import com.example.data.model.ProjectEntity
import com.example.data.model.RoomEntity
import com.example.data.model.SettingsEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull

class GasSuppressionRepository(private val db: AppDatabase) {

    val allProjects: Flow<List<ProjectEntity>> = db.projectDao().getAllProjects()
    val settingsFlow: Flow<SettingsEntity?> = db.settingsDao().getSettings()

    suspend fun getProjectById(id: Long): ProjectEntity? {
        return db.projectDao().getProjectById(id)
    }

    suspend fun createProject(project: ProjectEntity): Long {
        return db.projectDao().insertProject(project)
    }

    suspend fun updateProject(project: ProjectEntity) {
        db.projectDao().updateProject(project)
    }

    suspend fun deleteProject(project: ProjectEntity) {
        db.boqDao().deleteBoqForProject(project.id)
        db.roomDao().deleteRoomsForProject(project.id)
        db.projectDao().deleteProject(project)
    }

    suspend fun duplicateProject(project: ProjectEntity): Long {
        val newProj = project.copy(
            id = 0,
            projectName = "${project.projectName} (Copy)",
            projectCode = "${project.projectCode}-COPY",
            revision = "${project.revision}-REV",
            timestamp = System.currentTimeMillis()
        )
        val newProjId = db.projectDao().insertProject(newProj)

        // Duplicate rooms & recalculate BOQ
        val rooms = db.roomDao().getRoomsForProject(project.id).firstOrNull() ?: emptyList()
        val settings = db.settingsDao().getSettingsSync() ?: SettingsEntity()

        for (room in rooms) {
            val newRoom = room.copy(id = 0, projectId = newProjId)
            val newRoomId = db.roomDao().insertRoom(newRoom)
            val boqItems = BOQEngine.generateBoqForRoom(newRoom.copy(id = newRoomId), settings)
            db.boqDao().insertBoqItems(boqItems)
        }
        return newProjId
    }

    fun getRoomsForProject(projectId: Long): Flow<List<RoomEntity>> {
        return db.roomDao().getRoomsForProject(projectId)
    }

    suspend fun getRoomById(id: Long): RoomEntity? {
        return db.roomDao().getRoomById(id)
    }

    suspend fun saveRoom(room: RoomEntity): Long {
        val settings = db.settingsDao().getSettingsSync() ?: SettingsEntity()
        val roomId = if (room.id == 0L) {
            db.roomDao().insertRoom(room)
        } else {
            db.roomDao().updateRoom(room)
            room.id
        }

        // Regenerate BOQ for this room
        val updatedRoom = room.copy(id = roomId)
        db.boqDao().deleteBoqForRoom(roomId)
        val boqItems = BOQEngine.generateBoqForRoom(updatedRoom, settings)
        db.boqDao().insertBoqItems(boqItems)

        return roomId
    }

    suspend fun deleteRoom(room: RoomEntity) {
        db.boqDao().deleteBoqForRoom(room.id)
        db.roomDao().deleteRoom(room)
    }

    fun getBoqItemsForProject(projectId: Long): Flow<List<BoqItemEntity>> {
        return db.boqDao().getBoqItemsForProject(projectId)
    }

    fun getBoqItemsForRoom(roomId: Long): Flow<List<BoqItemEntity>> {
        return db.boqDao().getBoqItemsForRoom(roomId)
    }

    suspend fun updateBoqItem(item: BoqItemEntity) {
        db.boqDao().updateBoqItem(item)
    }

    suspend fun insertBoqItem(item: BoqItemEntity): Long {
        return db.boqDao().insertBoqItem(item)
    }

    suspend fun deleteBoqItem(item: BoqItemEntity) {
        db.boqDao().deleteBoqItem(item)
    }

    suspend fun saveSettings(settings: SettingsEntity) {
        db.settingsDao().saveSettings(settings)
    }
}
