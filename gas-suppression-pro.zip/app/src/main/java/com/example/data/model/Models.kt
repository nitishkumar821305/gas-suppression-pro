package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectCode: String,
    val projectName: String,
    val client: String,
    val consultant: String,
    val contractor: String,
    val location: String,
    val projectNumber: String,
    val revision: String,
    val date: String,
    val preparedBy: String,
    val checkedBy: String,
    val approvedBy: String,
    val remarks: String,
    val gstPercentage: Double = 18.0,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "rooms")
data class RoomEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: Long,
    val roomName: String,
    val systemType: String, // "CO2" or "IG541"
    val length: Double, // in selected unit
    val width: Double,  // in selected unit
    val height: Double, // in selected unit
    val unit: String = "metre", // "metre", "feet", "mm"
    val hazardType: String = "Electrical", // "Electrical", "Generator", "Surface", "Deep Seated"
    val designConcentration: Double = 40.0, // percentage
    val temperature: Double = 20.0, // Celsius
    val cylinderCapacity: Double = 45.0, // kg for CO2, or gas m3 for IG541
    val cylinderPressure: Int = 200, // bar for IG541
    val cylinderVolumeLiters: Double = 80.0, // L for IG541 cylinder
    val nozzleType: String = "360 Degree",
    val pipeMaterial: String = "ASTM A106 Grade B SCH 80",
    val remarks: String = ""
)

@Entity(tableName = "boq_items")
data class BoqItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: Long,
    val roomId: Long = 0, // 0 for project-wide summary
    val category: String, // "GAS / CYLINDERS", "DISCHARGE SYSTEM", "ACTUATION SYSTEM", "NOZZLES", "PIPING", "ACCESSORIES"
    val description: String,
    val specification: String,
    val make: String,
    val unit: String, // "No", "Set", "Mtr", "Kg", "Lot"
    val quantity: Double,
    val rate: Double,
    val remarks: String = "",
    val calculationSource: String = "",
    val isCustom: Boolean = false
)

@Entity(tableName = "settings")
data class SettingsEntity(
    @PrimaryKey val id: Int = 1,
    val co2CylinderCapacityKg: Double = 45.0,
    val ig541CylinderVolumeLiters: Double = 80.0,
    val ig541CylinderPressureBar: Int = 200,
    val co2DefaultConcentration: Double = 40.0,
    val ig541DefaultConcentration: Double = 38.0,
    val defaultGstPercentage: Double = 18.0,
    val defaultCo2RatePerKg: Double = 12.0,
    val defaultIg541RatePerM3: Double = 18.0,
    val defaultCylinderRate: Double = 450.0,
    val defaultNozzleRate: Double = 65.0,
    val defaultPipeRatePerMtr: Double = 35.0
)
