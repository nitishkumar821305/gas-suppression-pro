package com.example.data.db

import androidx.room.*
import com.example.data.model.BoqItemEntity
import com.example.data.model.ProjectEntity
import com.example.data.model.RoomEntity
import com.example.data.model.SettingsEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects ORDER BY timestamp DESC")
    fun getAllProjects(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE id = :id")
    suspend fun getProjectById(id: Long): ProjectEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: ProjectEntity): Long

    @Update
    suspend fun updateProject(project: ProjectEntity)

    @Delete
    suspend fun deleteProject(project: ProjectEntity)
}

@Dao
interface RoomDao {
    @Query("SELECT * FROM rooms WHERE projectId = :projectId ORDER BY id ASC")
    fun getRoomsForProject(projectId: Long): Flow<List<RoomEntity>>

    @Query("SELECT * FROM rooms WHERE id = :id")
    suspend fun getRoomById(id: Long): RoomEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRoom(room: RoomEntity): Long

    @Update
    suspend fun updateRoom(room: RoomEntity)

    @Delete
    suspend fun deleteRoom(room: RoomEntity)

    @Query("DELETE FROM rooms WHERE projectId = :projectId")
    suspend fun deleteRoomsForProject(projectId: Long)
}

@Dao
interface BoqDao {
    @Query("SELECT * FROM boq_items WHERE projectId = :projectId ORDER BY id ASC")
    fun getBoqItemsForProject(projectId: Long): Flow<List<BoqItemEntity>>

    @Query("SELECT * FROM boq_items WHERE roomId = :roomId ORDER BY id ASC")
    fun getBoqItemsForRoom(roomId: Long): Flow<List<BoqItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBoqItem(item: BoqItemEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBoqItems(items: List<BoqItemEntity>)

    @Update
    suspend fun updateBoqItem(item: BoqItemEntity)

    @Delete
    suspend fun deleteBoqItem(item: BoqItemEntity)

    @Query("DELETE FROM boq_items WHERE roomId = :roomId")
    suspend fun deleteBoqForRoom(roomId: Long)

    @Query("DELETE FROM boq_items WHERE projectId = :projectId")
    suspend fun deleteBoqForProject(projectId: Long)
}

@Dao
interface SettingsDao {
    @Query("SELECT * FROM settings WHERE id = 1")
    fun getSettings(): Flow<SettingsEntity?>

    @Query("SELECT * FROM settings WHERE id = 1")
    suspend fun getSettingsSync(): SettingsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveSettings(settings: SettingsEntity)
}
