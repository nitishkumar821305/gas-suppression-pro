package com.example.calculations

import kotlin.math.ceil
import kotlin.math.max

data class IG541DesignResult(
    val roomAreaM2: Double,
    val roomVolumeM3: Double,
    val designConcentration: Double,
    val designTempC: Double,
    val cylinderPressureBar: Int,
    val cylinderVolumeLiters: Double,
    val gasCapacityPerCylinderM3: Double,
    val requiredGasM3: Double,
    val cylinderCount: Int,
    val totalProvidedGasM3: Double,
    val masterCylinderCount: Int,
    val slaveCylinderCount: Int,
    val dischargeHoseCount: Int,
    val nrvCount: Int,
    val actuationHoseCount: Int,
    val pneumaticActuatorCount: Int,
    val pressureReducingOrificeCount: Int,
    val manifoldSizeInch: String,
    val nozzleCount: Int,
    val pipeLengthMtr: Double,
    val pipeSupportCount: Int,
    val calculationSteps: List<CalculationStep>
)

object IG541Engine {
    fun calculate(
        length: Double,
        width: Double,
        height: Double,
        unit: String = "metre",
        designConcentration: Double = 38.0,
        tempC: Double = 20.0,
        cylinderPressureBar: Int = 200,
        cylinderVolumeLiters: Double = 80.0
    ): IG541DesignResult {
        val area = UnitConversion.calculateArea(length, width, unit)
        val volume = UnitConversion.calculateVolume(length, width, height, unit)

        // Free gas capacity per cylinder based on pressure and volume
        val gasCapM3 = when {
            cylinderVolumeLiters >= 130 && cylinderPressureBar >= 280 -> 37.1
            cylinderVolumeLiters >= 70 && cylinderPressureBar >= 280 -> 21.2
            else -> 15.2 // 80L @ 200 bar
        }

        // Required Gas Volume X (m3) = Volume * (C / (100 - C))
        val concFactor = designConcentration / (100.0 - designConcentration)
        val tempCorrection = (273.15 + 15.0) / (273.15 + tempC) // NFPA 2001 standard temp ratio
        val requiredGasM3 = volume * concFactor * tempCorrection

        val numCylinders = max(1, ceil(requiredGasM3 / gasCapM3).toInt())
        val providedGasM3 = numCylinders * gasCapM3

        val masterCount = 1
        val slaveCount = max(0, numCylinders - 1)

        val dischargeHoseCount = numCylinders
        val nrvCount = numCylinders
        val actuationHoseCount = slaveCount
        val pneumaticActuatorCount = slaveCount
        val orificeCount = 1

        val manifoldSize = when {
            numCylinders <= 3 -> "2\" (DN50) SCH 80"
            numCylinders <= 8 -> "2.5\" (DN65) SCH 80"
            numCylinders <= 16 -> "3\" (DN80) SCH 80"
            else -> "4\" (DN100) SCH 80"
        }

        // Nozzles: 1 per 30 m2, min 2
        val nozzleCount = max(2, ceil(area / 30.0).toInt())

        val pipeLength = 15.0 + (length + width + height) * 0.80
        val pipeSupports = max(5, ceil(pipeLength / 2.0).toInt())

        val steps = listOf(
            CalculationStep(
                stepName = "1. Protected Volume",
                formula = "V = L × W × H",
                value = UnitConversion.formatDouble(volume, 2),
                unit = "m³",
                explanation = "Room floor area = ${UnitConversion.formatDouble(area, 2)} m², Height = ${UnitConversion.formatDouble(UnitConversion.toMeters(height, unit), 2)} m"
            ),
            CalculationStep(
                stepName = "2. Design Concentration Factor",
                formula = "Factor = C / (100 - C)",
                value = UnitConversion.formatDouble(concFactor, 4),
                unit = "ratio",
                explanation = "Target IG-541 concentration = $designConcentration% at $tempC °C (NFPA 2001)"
            ),
            CalculationStep(
                stepName = "3. Required Free Gas Volume",
                formula = "X = V × [C / (100 - C)] × TempRatio",
                value = UnitConversion.formatDouble(requiredGasM3, 2),
                unit = "m³ (at std conditions)",
                explanation = "Free gas volume required to extinguish fire safely"
            ),
            CalculationStep(
                stepName = "4. Cylinder Capacity",
                formula = "Gas Capacity = $gasCapM3 m³ per cylinder",
                value = "$gasCapM3 m³ / cylinder",
                unit = "m³",
                explanation = "Specification: $cylinderVolumeLiters Liters @ $cylinderPressureBar bar"
            ),
            CalculationStep(
                stepName = "5. Cylinder Quantity Calculation",
                formula = "N_cyl = Ceiling(Required Gas / Cylinder Gas Capacity)",
                value = "$numCylinders Cylinders",
                unit = "units",
                explanation = "Total free gas provided: ${UnitConversion.formatDouble(providedGasM3, 2)} m³"
            ),
            CalculationStep(
                stepName = "6. Nozzle Distribution",
                formula = "N_nozzle = Max(2, Ceiling(Area / 30 m²))",
                value = "$nozzleCount Nozzles",
                unit = "360° / 180° pattern",
                explanation = "Calculated for uniform coverage over ${UnitConversion.formatDouble(area, 2)} m² floor area"
            )
        )

        return IG541DesignResult(
            roomAreaM2 = area,
            roomVolumeM3 = volume,
            designConcentration = designConcentration,
            designTempC = tempC,
            cylinderPressureBar = cylinderPressureBar,
            cylinderVolumeLiters = cylinderVolumeLiters,
            gasCapacityPerCylinderM3 = gasCapM3,
            requiredGasM3 = requiredGasM3,
            cylinderCount = numCylinders,
            totalProvidedGasM3 = providedGasM3,
            masterCylinderCount = masterCount,
            slaveCylinderCount = slaveCount,
            dischargeHoseCount = dischargeHoseCount,
            nrvCount = nrvCount,
            actuationHoseCount = actuationHoseCount,
            pneumaticActuatorCount = pneumaticActuatorCount,
            pressureReducingOrificeCount = orificeCount,
            manifoldSizeInch = manifoldSize,
            nozzleCount = nozzleCount,
            pipeLengthMtr = pipeLength,
            pipeSupportCount = pipeSupports,
            calculationSteps = steps
        )
    }
}
