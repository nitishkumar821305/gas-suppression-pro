package com.example.calculations

import kotlin.math.ceil
import kotlin.math.max

data class CO2DesignResult(
    val roomAreaM2: Double,
    val roomVolumeM3: Double,
    val hazardType: String,
    val designConcentration: Double,
    val designTempC: Double,
    val specificVolumeM3PerKg: Double,
    val floodingFactorKgPerM3: Double,
    val calculatedGasKg: Double,
    val safetyFactorMultiplier: Double,
    val totalRequiredGasKg: Double,
    val cylinderCapacityKg: Double,
    val cylinderCount: Int,
    val totalProvidedGasKg: Double,
    val masterCylinderCount: Int,
    val slaveCylinderCount: Int,
    val dischargeHoseCount: Int,
    val nrvCount: Int,
    val actuationHoseCount: Int,
    val pneumaticActuatorCount: Int,
    val solenoidValveCount: Int,
    val manifoldSizeInch: String,
    val nozzleCount: Int,
    val pipeLengthMtr: Double,
    val pipeSupportCount: Int,
    val calculationSteps: List<CalculationStep>
)

data class CalculationStep(
    val stepName: String,
    val formula: String,
    val value: String,
    val unit: String,
    val explanation: String
)

object CO2Engine {
    fun calculate(
        length: Double,
        width: Double,
        height: Double,
        unit: String = "metre",
        hazardType: String = "Electrical",
        designConcentration: Double = 50.0,
        tempC: Double = 20.0,
        cylinderCapacityKg: Double = 45.0
    ): CO2DesignResult {
        val area = UnitConversion.calculateArea(length, width, unit)
        val volume = UnitConversion.calculateVolume(length, width, height, unit)

        // Specific Volume (m3/kg) = 0.5280 + 0.0021 * T(deg C) per NFPA 12
        val specVol = 0.5280 + (0.0021 * tempC)

        // Flooding Factor (kg/m3) = (C / (100 - C)) / S
        val concRatio = designConcentration / (100.0 - designConcentration)
        val floodingFactor = concRatio / specVol

        val baseGasKg = volume * floodingFactor
        val safetyFactor = 1.10 // 10% safety and opening allowance
        val totalGasKg = baseGasKg * safetyFactor

        val numCylinders = max(1, ceil(totalGasKg / cylinderCapacityKg).toInt())
        val providedGasKg = numCylinders * cylinderCapacityKg

        val masterCount = 1
        val slaveCount = max(0, numCylinders - 1)

        val dischargeHoseCount = numCylinders
        val nrvCount = numCylinders
        val actuationHoseCount = slaveCount
        val pneumaticActuatorCount = slaveCount
        val solenoidValveCount = 1

        val manifoldSize = when {
            numCylinders <= 2 -> "1\" (DN25) SCH 80"
            numCylinders <= 4 -> "1.5\" (DN40) SCH 80"
            numCylinders <= 8 -> "2\" (DN50) SCH 80"
            numCylinders <= 14 -> "2.5\" (DN65) SCH 80"
            else -> "3\" (DN80) SCH 80"
        }

        // Nozzles: 1 nozzle per 25 m2, min 2
        val nozzleCount = max(2, ceil(area / 25.0).toInt())

        // Pipe estimation based on room size
        val pipeLength = 12.0 + (length + width + height) * 0.75
        val pipeSupports = max(4, ceil(pipeLength / 2.0).toInt())

        val steps = listOf(
            CalculationStep(
                stepName = "1. Protected Volume",
                formula = "V = L × W × H (converted to meters)",
                value = UnitConversion.formatDouble(volume, 2),
                unit = "m³",
                explanation = "Calculated internal dimensions: Area = ${UnitConversion.formatDouble(area, 2)} m², Height = ${UnitConversion.formatDouble(UnitConversion.toMeters(height, unit), 2)} m"
            ),
            CalculationStep(
                stepName = "2. CO₂ Specific Volume (S)",
                formula = "S = 0.5280 + (0.0021 × T)",
                value = UnitConversion.formatDouble(specVol, 4),
                unit = "m³/kg",
                explanation = "NFPA 12 specific volume formula at design temperature $tempC °C"
            ),
            CalculationStep(
                stepName = "3. Volumetric Flooding Factor (k)",
                formula = "k = [C / (100 - C)] / S",
                value = UnitConversion.formatDouble(floodingFactor, 4),
                unit = "kg/m³",
                explanation = "Required CO₂ mass per cubic meter for $designConcentration% concentration"
            ),
            CalculationStep(
                stepName = "4. Calculated Base Agent Mass",
                formula = "Q_base = V × k",
                value = UnitConversion.formatDouble(baseGasKg, 2),
                unit = "kg",
                explanation = "Minimum theoretical agent mass required to flood $volume m³"
            ),
            CalculationStep(
                stepName = "5. Design Safety Total Agent",
                formula = "Q_total = Q_base × 1.10 (10% Safety & Opening margin)",
                value = UnitConversion.formatDouble(totalGasKg, 2),
                unit = "kg",
                explanation = "Includes standard engineering margin for unclosable leakage"
            ),
            CalculationStep(
                stepName = "6. Cylinder Sizing & Quantity",
                formula = "N_cyl = Ceiling(Q_total / Capacity)",
                value = "$numCylinders Cylinders",
                unit = "units ($cylinderCapacityKg kg each)",
                explanation = "Total CO₂ agent supplied: ${UnitConversion.formatDouble(providedGasKg, 2)} kg"
            ),
            CalculationStep(
                stepName = "7. Nozzle Sizing",
                formula = "N_nozzle = Max(2, Ceiling(Area / 25 m²))",
                value = "$nozzleCount Nozzles",
                unit = "360° / 180° pattern",
                explanation = "Provides uniform discharge across floor area of ${UnitConversion.formatDouble(area, 2)} m²"
            )
        )

        return CO2DesignResult(
            roomAreaM2 = area,
            roomVolumeM3 = volume,
            hazardType = hazardType,
            designConcentration = designConcentration,
            designTempC = tempC,
            specificVolumeM3PerKg = specVol,
            floodingFactorKgPerM3 = floodingFactor,
            calculatedGasKg = baseGasKg,
            safetyFactorMultiplier = safetyFactor,
            totalRequiredGasKg = totalGasKg,
            cylinderCapacityKg = cylinderCapacityKg,
            cylinderCount = numCylinders,
            totalProvidedGasKg = providedGasKg,
            masterCylinderCount = masterCount,
            slaveCylinderCount = slaveCount,
            dischargeHoseCount = dischargeHoseCount,
            nrvCount = nrvCount,
            actuationHoseCount = actuationHoseCount,
            pneumaticActuatorCount = pneumaticActuatorCount,
            solenoidValveCount = solenoidValveCount,
            manifoldSizeInch = manifoldSize,
            nozzleCount = nozzleCount,
            pipeLengthMtr = pipeLength,
            pipeSupportCount = pipeSupports,
            calculationSteps = steps
        )
    }
}
