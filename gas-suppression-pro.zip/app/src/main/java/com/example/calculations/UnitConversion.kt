package com.example.calculations

import kotlin.math.roundToInt

object UnitConversion {
    fun toMeters(value: Double, unit: String): Double {
        return when (unit.lowercase()) {
            "mm", "millimetre", "millimeter" -> value / 1000.0
            "ft", "feet", "foot" -> value * 0.3048
            "m", "metre", "meter" -> value
            else -> value
        }
    }

    fun calculateArea(length: Double, width: Double, unit: String): Double {
        val lMeters = toMeters(length, unit)
        val wMeters = toMeters(width, unit)
        return lMeters * wMeters
    }

    fun calculateVolume(length: Double, width: Double, height: Double, unit: String): Double {
        val lMeters = toMeters(length, unit)
        val wMeters = toMeters(width, unit)
        val hMeters = toMeters(height, unit)
        return lMeters * wMeters * hMeters
    }

    fun formatDouble(value: Double, decimals: Int = 2): String {
        return String.format("%.${decimals}f", value)
    }

    fun roundUp(value: Double): Int {
        return kotlin.math.ceil(value).toInt()
    }
}
