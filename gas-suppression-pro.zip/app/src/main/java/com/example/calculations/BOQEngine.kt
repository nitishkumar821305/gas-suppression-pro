package com.example.calculations

import com.example.data.model.BoqItemEntity
import com.example.data.model.RoomEntity
import com.example.data.model.SettingsEntity

object BOQEngine {

    fun generateBoqForRoom(
        room: RoomEntity,
        settings: SettingsEntity = SettingsEntity()
    ): List<BoqItemEntity> {
        val items = mutableListOf<BoqItemEntity>()
        val projId = room.projectId
        val roomId = room.id

        if (room.systemType.uppercase() == "CO2") {
            val res = CO2Engine.calculate(
                length = room.length,
                width = room.width,
                height = room.height,
                unit = room.unit,
                hazardType = room.hazardType,
                designConcentration = room.designConcentration,
                tempC = room.temperature,
                cylinderCapacityKg = room.cylinderCapacity
            )

            // 1. GAS / CYLINDERS
            items.add(
                BoqItemEntity(
                    projectId = projId,
                    roomId = roomId,
                    category = "GAS / CYLINDERS",
                    description = "High Pressure CO₂ Cylinder Assembly (45 kg / 68L)",
                    specification = "Seamless Manganese Steel Cylinder rated at 250 bar testing pressure, filled with ${room.cylinderCapacity} kg CO₂ agent",
                    make = "Standard / Tyco / Kidde",
                    unit = "No",
                    quantity = res.cylinderCount.toDouble(),
                    rate = settings.defaultCylinderRate,
                    remarks = "Includes main cylinder valve and burst disc",
                    calculationSource = "Quantity = Ceiling(Required Gas ${UnitConversion.formatDouble(res.totalRequiredGasKg, 2)} kg / ${room.cylinderCapacity} kg) = ${res.cylinderCount} Cylinders"
                )
            )

            items.add(
                BoqItemEntity(
                    projectId = projId,
                    roomId = roomId,
                    category = "GAS / CYLINDERS",
                    description = "Carbon Dioxide (CO₂) Gas Agent Refill",
                    specification = "Commercial grade CO₂ agent strictly adhering to NFPA 12 requirements",
                    make = "Standard Gas Refill",
                    unit = "Kg",
                    quantity = res.totalProvidedGasKg,
                    rate = settings.defaultCo2RatePerKg,
                    remarks = "Total net weight of CO₂ agent provided",
                    calculationSource = "Quantity = ${res.cylinderCount} Cylinders × ${room.cylinderCapacity} kg = ${UnitConversion.formatDouble(res.totalProvidedGasKg, 2)} kg"
                )
            )

            // 2. DISCHARGE SYSTEM
            items.add(
                BoqItemEntity(
                    projectId = projId,
                    roomId = roomId,
                    category = "DISCHARGE SYSTEM",
                    description = "Flexible High Pressure Discharge Hose (DN20)",
                    specification = "300 bar rated double wire braided flexible rubber hose, length 500mm",
                    make = "Standard / Tyco",
                    unit = "No",
                    quantity = res.dischargeHoseCount.toDouble(),
                    rate = 45.0,
                    remarks = "1 hose per cylinder to header manifold",
                    calculationSource = "Source: 1 Hose per Cylinder (${res.cylinderCount} cylinders)"
                )
            )

            items.add(
                BoqItemEntity(
                    projectId = projId,
                    roomId = roomId,
                    category = "DISCHARGE SYSTEM",
                    description = "Non-Return Check Valve (NRV DN20)",
                    specification = "High pressure brass check valve, 300 bar rating",
                    make = "Standard / Tyco",
                    unit = "No",
                    quantity = res.nrvCount.toDouble(),
                    rate = 35.0,
                    remarks = "Prevents backflow from header into disconnected cylinder",
                    calculationSource = "Source: 1 Check Valve per Cylinder (${res.cylinderCount} cylinders)"
                )
            )

            items.add(
                BoqItemEntity(
                    projectId = projId,
                    roomId = roomId,
                    category = "DISCHARGE SYSTEM",
                    description = "Collector Manifold Header Pipe",
                    specification = "SCH 80 ASTM A106 Seamless Steel Pipe with welded sockets, Size: ${res.manifoldSizeInch}",
                    make = "Standard / Jindal",
                    unit = "Lot",
                    quantity = 1.0,
                    rate = 220.0 + (res.cylinderCount * 25.0),
                    remarks = "Includes safety relief valve connection",
                    calculationSource = "Source: Sized according to ${res.cylinderCount} cylinders flow requirement (${res.manifoldSizeInch})"
                )
            )

            // 3. ACTUATION SYSTEM
            items.add(
                BoqItemEntity(
                    projectId = projId,
                    roomId = roomId,
                    category = "ACTUATION SYSTEM",
                    description = "Solenoid Actuator with Manual Lever Release",
                    specification = "24V DC Electromagnetic actuator with manual strike button for Master Cylinder",
                    make = "Standard / Kidde",
                    unit = "Set",
                    quantity = res.solenoidValveCount.toDouble(),
                    rate = 180.0,
                    remarks = "Mounted on Master Cylinder",
                    calculationSource = "Source: 1 Solenoid assembly per cylinder bank"
                )
            )

            if (res.slaveCylinderCount > 0) {
                items.add(
                    BoqItemEntity(
                        projectId = projId,
                        roomId = roomId,
                        category = "ACTUATION SYSTEM",
                        description = "Pneumatic Actuator Assembly",
                        specification = "Pneumatic slave actuator mounted on cylinder valve",
                        make = "Standard / Kidde",
                        unit = "No",
                        quantity = res.slaveCylinderCount.toDouble(),
                        rate = 85.0,
                        remarks = "Mounted on Slave Cylinders",
                        calculationSource = "Source: 1 Pneumatic actuator for each slave cylinder (${res.slaveCylinderCount} slave cylinders)"
                    )
                )

                items.add(
                    BoqItemEntity(
                        projectId = projId,
                        roomId = roomId,
                        category = "ACTUATION SYSTEM",
                        description = "Flexible Pilot Actuation Hose (DN6)",
                        specification = "High pressure flexible microbore pilot hose, 250 bar rated",
                        make = "Standard",
                        unit = "No",
                        quantity = res.actuationHoseCount.toDouble(),
                        rate = 25.0,
                        remarks = "Interconnects master to slave pneumatic heads",
                        calculationSource = "Source: 1 Pilot hose per slave cylinder (${res.actuationHoseCount} hoses)"
                    )
                )
            }

            // 4. NOZZLES
            items.add(
                BoqItemEntity(
                    projectId = projId,
                    roomId = roomId,
                    category = "NOZZLES",
                    description = "CO₂ Discharge Nozzles (1/2\" / 3/4\" NPT)",
                    specification = "Brass/Stainless Steel 360° or 180° radial discharge nozzles with orifice plate",
                    make = "Standard / Tyco",
                    unit = "No",
                    quantity = res.nozzleCount.toDouble(),
                    rate = settings.defaultNozzleRate,
                    remarks = "Designed for uniform distribution",
                    calculationSource = "Source: Max(2, Ceiling(Floor Area ${UnitConversion.formatDouble(res.roomAreaM2, 2)} m² / 25 m²)) = ${res.nozzleCount} Nozzles"
                )
            )

            // 5. PIPING
            items.add(
                BoqItemEntity(
                    projectId = projId,
                    roomId = roomId,
                    category = "PIPING",
                    description = "Seamless Steel Pipe ASTM A106 Grade B SCH 80",
                    specification = "High pressure seamless steel piping, threaded / socket welded fittings",
                    make = "Jindal / MSL",
                    unit = "Mtr",
                    quantity = UnitConversion.formatDouble(res.pipeLengthMtr, 1).toDouble(),
                    rate = settings.defaultPipeRatePerMtr,
                    remarks = "Pipe run from cylinder bank to room nozzles",
                    calculationSource = "Source: Estimated length based on room perimeter + elevation rise = ${UnitConversion.formatDouble(res.pipeLengthMtr, 1)} m"
                )
            )

            // 6. ACCESSORIES
            items.add(
                BoqItemEntity(
                    projectId = projId,
                    roomId = roomId,
                    category = "ACCESSORIES",
                    description = "Cylinder Mounting Brackets & Straps",
                    specification = "Heavy duty powder coated steel wall rack with quick release clamps",
                    make = "Custom Fabricated",
                    unit = "Set",
                    quantity = 1.0,
                    rate = 120.0 + (res.cylinderCount * 15.0),
                    remarks = "Wall/floor mounting frame for ${res.cylinderCount} cylinders",
                    calculationSource = "Source: Standard rack frame for ${res.cylinderCount} cylinders"
                )
            )

            items.add(
                BoqItemEntity(
                    projectId = projId,
                    roomId = roomId,
                    category = "ACCESSORIES",
                    description = "Warning Placards & Operating Instruction Signs",
                    specification = "Rigid plastic / aluminum warning signboards per NFPA 12 requirements",
                    make = "Standard",
                    unit = "Set",
                    quantity = 1.0,
                    rate = 45.0,
                    remarks = "Entrance warning & manual release station signs",
                    calculationSource = "Source: Standard warning signage kit per protected enclosure"
                )
            )

        } else {
            // IG-541 System BOQ
            val res = IG541Engine.calculate(
                length = room.length,
                width = room.width,
                height = room.height,
                unit = room.unit,
                designConcentration = room.designConcentration,
                tempC = room.temperature,
                cylinderPressureBar = room.cylinderPressure,
                cylinderVolumeLiters = room.cylinderVolumeLiters
            )

            // 1. GAS / CYLINDERS
            items.add(
                BoqItemEntity(
                    projectId = projId,
                    roomId = roomId,
                    category = "GAS / CYLINDERS",
                    description = "IG-541 Inergen High Pressure Cylinder Assembly (${room.cylinderVolumeLiters}L / ${room.cylinderPressure} bar)",
                    specification = "Seamless High Strength Alloy Steel Cylinder charged at ${room.cylinderPressure} bar, containing ${res.gasCapacityPerCylinderM3} m³ IG-541 agent",
                    make = "Tyco / FirePro / Minimax",
                    unit = "No",
                    quantity = res.cylinderCount.toDouble(),
                    rate = 650.0,
                    remarks = "Equipped with high pressure cylinder valve & gauge",
                    calculationSource = "Quantity = Ceiling(Required Gas ${UnitConversion.formatDouble(res.requiredGasM3, 2)} m³ / ${res.gasCapacityPerCylinderM3} m³) = ${res.cylinderCount} Cylinders"
                )
            )

            items.add(
                BoqItemEntity(
                    projectId = projId,
                    roomId = roomId,
                    category = "GAS / CYLINDERS",
                    description = "IG-541 Clean Agent Gas Refill (52% N₂, 40% Ar, 8% CO₂)",
                    specification = "Pure inert clean agent gas mix adhering to NFPA 2001",
                    make = "Standard Gas Refill",
                    unit = "Mtr³",
                    quantity = res.totalProvidedGasM3,
                    rate = settings.defaultIg541RatePerM3,
                    remarks = "Total volume of free gas agent provided",
                    calculationSource = "Quantity = ${res.cylinderCount} Cylinders × ${res.gasCapacityPerCylinderM3} m³ = ${UnitConversion.formatDouble(res.totalProvidedGasM3, 2)} m³"
                )
            )

            // 2. DISCHARGE SYSTEM
            items.add(
                BoqItemEntity(
                    projectId = projId,
                    roomId = roomId,
                    category = "DISCHARGE SYSTEM",
                    description = "High Pressure Flexible Discharge Hose (300 bar rated)",
                    specification = "Stainless steel wire braided high pressure flexible discharge connection",
                    make = "Tyco / Minimax",
                    unit = "No",
                    quantity = res.dischargeHoseCount.toDouble(),
                    rate = 55.0,
                    remarks = "Connecting cylinder to manifold",
                    calculationSource = "Source: 1 Discharge hose per cylinder (${res.cylinderCount} cylinders)"
                )
            )

            items.add(
                BoqItemEntity(
                    projectId = projId,
                    roomId = roomId,
                    category = "DISCHARGE SYSTEM",
                    description = "Check Valve / Non-Return Valve (NRV DN20)",
                    specification = "300 bar rated brass non-return valve",
                    make = "Tyco / Minimax",
                    unit = "No",
                    quantity = res.nrvCount.toDouble(),
                    rate = 40.0,
                    remarks = "Protects manifold from back pressure",
                    calculationSource = "Source: 1 Check valve per cylinder (${res.cylinderCount} cylinders)"
                )
            )

            items.add(
                BoqItemEntity(
                    projectId = projId,
                    roomId = roomId,
                    category = "DISCHARGE SYSTEM",
                    description = "Pressure Reducing Orifice Flange Assembly (PRO)",
                    specification = "Calibrated stainless steel orifice plate for downstream pressure reduction to ~60 bar",
                    make = "Tyco / FirePro",
                    unit = "Set",
                    quantity = res.pressureReducingOrificeCount.toDouble(),
                    rate = 210.0,
                    remarks = "Limits pipe pressure downstream of manifold header",
                    calculationSource = "Source: 1 Pressure Regulator / Orifice plate set per cylinder bank"
                )
            )

            // 3. ACTUATION SYSTEM
            items.add(
                BoqItemEntity(
                    projectId = projId,
                    roomId = roomId,
                    category = "ACTUATION SYSTEM",
                    description = "Electric Solenoid Actuator & Manual Strike Head",
                    specification = "24V DC electromagnetic actuator mounted on Master Cylinder",
                    make = "Tyco / Minimax",
                    unit = "Set",
                    quantity = 1.0,
                    rate = 195.0,
                    remarks = "Master actuation assembly",
                    calculationSource = "Source: 1 Solenoid assembly per master cylinder"
                )
            )

            if (res.slaveCylinderCount > 0) {
                items.add(
                    BoqItemEntity(
                        projectId = projId,
                        roomId = roomId,
                        category = "ACTUATION SYSTEM",
                        description = "Pneumatic Slave Actuator Head",
                        specification = "High pressure pneumatic actuator head for slave valves",
                        make = "Tyco / Minimax",
                        unit = "No",
                        quantity = res.slaveCylinderCount.toDouble(),
                        rate = 90.0,
                        remarks = "Mounted on Slave Cylinders",
                        calculationSource = "Source: 1 Pneumatic head per slave cylinder (${res.slaveCylinderCount} slave cylinders)"
                    )
                )

                items.add(
                    BoqItemEntity(
                        projectId = projId,
                        roomId = roomId,
                        category = "ACTUATION SYSTEM",
                        description = "High Pressure Pilot Line Actuation Hose",
                        specification = "250 bar rated flexible actuation hose",
                        make = "Standard",
                        unit = "No",
                        quantity = res.actuationHoseCount.toDouble(),
                        rate = 28.0,
                        remarks = "Interconnects pilot line across cylinders",
                        calculationSource = "Source: 1 Pilot hose per slave cylinder (${res.actuationHoseCount} hoses)"
                    )
                )
            }

            // 4. NOZZLES
            items.add(
                BoqItemEntity(
                    projectId = projId,
                    roomId = roomId,
                    category = "NOZZLES",
                    description = "IG-541 Radial Discharge Nozzles (360° / 180°)",
                    specification = "Stainless Steel / Brass engineered orifice discharge nozzles",
                    make = "Tyco / Minimax",
                    unit = "No",
                    quantity = res.nozzleCount.toDouble(),
                    rate = settings.defaultNozzleRate,
                    remarks = "Calibrated for room dimensions",
                    calculationSource = "Source: Max(2, Ceiling(Floor Area ${UnitConversion.formatDouble(res.roomAreaM2, 2)} m² / 30 m²)) = ${res.nozzleCount} Nozzles"
                )
            )

            // 5. PIPING
            items.add(
                BoqItemEntity(
                    projectId = projId,
                    roomId = roomId,
                    category = "PIPING",
                    description = "Seamless Steel Pipe ASTM A106 Grade B SCH 40/80",
                    specification = "High pressure seamless steel distribution pipe network",
                    make = "Jindal / MSL",
                    unit = "Mtr",
                    quantity = UnitConversion.formatDouble(res.pipeLengthMtr, 1).toDouble(),
                    rate = settings.defaultPipeRatePerMtr,
                    remarks = "From pressure regulator downstream to nozzles",
                    calculationSource = "Source: Estimated length based on room dimensions = ${UnitConversion.formatDouble(res.pipeLengthMtr, 1)} m"
                )
            )

            // 6. ACCESSORIES
            items.add(
                BoqItemEntity(
                    projectId = projId,
                    roomId = roomId,
                    category = "ACCESSORIES",
                    description = "Cylinder Mounting Rack & Brackets Frame",
                    specification = "Heavy duty steel frame wall/floor structure with clamping straps",
                    make = "Custom Fabricated",
                    unit = "Set",
                    quantity = 1.0,
                    rate = 140.0 + (res.cylinderCount * 18.0),
                    remarks = "Frame sized for ${res.cylinderCount} cylinders",
                    calculationSource = "Source: Frame sized for ${res.cylinderCount} cylinders"
                )
            )

            items.add(
                BoqItemEntity(
                    projectId = projId,
                    roomId = roomId,
                    category = "ACCESSORIES",
                    description = "Pressure Switch (Discharge Alarm)",
                    specification = "IP65 Weatherproof discharge pressure switch with NO/NC contacts",
                    make = "Honeywell / Danfoss",
                    unit = "No",
                    quantity = 1.0,
                    rate = 110.0,
                    remarks = "Triggers fire alarm panel upon gas release",
                    calculationSource = "Source: 1 Pressure switch per system header"
                )
            )
        }

        return items
    }
}
