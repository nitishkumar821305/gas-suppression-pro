package com.example.calculations

object ValidationEngine {
    data class ValidationResult(
        val isValid: Boolean,
        val errorMessage: String? = null
    )

    fun validateRoomInputs(
        lengthStr: String,
        widthStr: String,
        heightStr: String,
        designConcentrationStr: String
    ): ValidationResult {
        val length = lengthStr.toDoubleOrNull()
        if (length == null || length <= 0) {
            return ValidationResult(false, "Please enter a valid room length greater than zero.")
        }

        val width = widthStr.toDoubleOrNull()
        if (width == null || width <= 0) {
            return ValidationResult(false, "Please enter a valid room width greater than zero.")
        }

        val height = heightStr.toDoubleOrNull()
        if (height == null || height <= 0) {
            return ValidationResult(false, "Please enter a valid room height greater than zero.")
        }

        val conc = designConcentrationStr.toDoubleOrNull()
        if (conc == null || conc <= 0 || conc >= 100) {
            return ValidationResult(false, "Please enter a valid design concentration percentage (e.g. 34% - 50%).")
        }

        return ValidationResult(true)
    }
}
