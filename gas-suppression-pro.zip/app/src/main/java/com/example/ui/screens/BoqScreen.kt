package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BoqItemEntity
import com.example.ui.components.CalculationTraceabilityDialog
import com.example.ui.components.EngineeringDisclaimerCard
import com.example.ui.navigation.Screen
import com.example.ui.viewmodel.GasSuppressionViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BoqScreen(
    viewModel: GasSuppressionViewModel,
    onNavigate: (String) -> Unit
) {
    val project by viewModel.selectedProject.collectAsState()
    val boqItems by viewModel.boqForSelectedProject.collectAsState()

    var selectedTraceabilityItem by remember { mutableStateOf<BoqItemEntity?>(null) }
    var editingItem by remember { mutableStateOf<BoqItemEntity?>(null) }
    var showAddItemDialog by remember { mutableStateOf(false) }

    val categories = listOf(
        "GAS / CYLINDERS",
        "DISCHARGE SYSTEM",
        "ACTUATION SYSTEM",
        "NOZZLES",
        "PIPING",
        "ACCESSORIES"
    )

    val gstRate = (project?.gstPercentage ?: 18.0) / 100.0
    val subtotal = boqItems.sumOf { it.quantity * it.rate }
    val gstAmount = subtotal * gstRate
    val grandTotal = subtotal + gstAmount

    if (project == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Please select or create a project first.", style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(12.dp))
                Button(onClick = { onNavigate(Screen.Projects.route) }) {
                    Text("Select Project")
                }
            }
        }
        return
    }

    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAddItemDialog = true },
                icon = { Icon(Icons.Default.Add, contentDescription = "Add Item") },
                text = { Text("Add Custom Item") },
                containerColor = MaterialTheme.colorScheme.primary
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header & Financial Summary
            item {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Bill of Quantities (BOQ)",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Project: ${project!!.projectName} (${project!!.projectCode})",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                                )
                            }
                            IconButton(onClick = { onNavigate(Screen.Reports.route) }) {
                                Icon(Icons.Default.Print, contentDescription = "Report Preview")
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Divider()
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Subtotal:", style = MaterialTheme.typography.labelMedium)
                                Text("$ ${String.format("%.2f", subtotal)}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            }
                            Column {
                                Text("GST (${project!!.gstPercentage}%):", style = MaterialTheme.typography.labelMedium)
                                Text("$ ${String.format("%.2f", gstAmount)}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            }
                            Column {
                                Text("Grand Total:", style = MaterialTheme.typography.labelMedium)
                                Text("$ ${String.format("%.2f", grandTotal)}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }

            // Categorized BOQ Tables
            categories.forEach { category ->
                val categoryItems = boqItems.filter { it.category.equals(category, ignoreCase = true) }
                if (categoryItems.isNotEmpty()) {
                    item {
                        Card(modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Surface(
                                    color = MaterialTheme.colorScheme.secondaryContainer,
                                    shape = MaterialTheme.shapes.small,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = category,
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSecondaryContainer
                                        )
                                        Text(
                                            text = "Subtotal: $ ${String.format("%.2f", categoryItems.sumOf { it.quantity * it.rate })}",
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                // Horizontal Scroll Table View
                                val scrollState = rememberScrollState()
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(scrollState)
                                ) {
                                    Column {
                                        // Table Header
                                        Row(
                                            modifier = Modifier
                                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                                .padding(vertical = 8.dp, horizontal = 4.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            TableCell(text = "S.No", width = 50.dp, isHeader = true)
                                            TableCell(text = "Description", width = 180.dp, isHeader = true)
                                            TableCell(text = "Specification", width = 160.dp, isHeader = true)
                                            TableCell(text = "Make", width = 100.dp, isHeader = true)
                                            TableCell(text = "Unit", width = 50.dp, isHeader = true)
                                            TableCell(text = "Qty [Trace]", width = 90.dp, isHeader = true)
                                            TableCell(text = "Rate ($)", width = 80.dp, isHeader = true)
                                            TableCell(text = "Amount ($)", width = 90.dp, isHeader = true)
                                            TableCell(text = "Actions", width = 80.dp, isHeader = true)
                                        }

                                        categoryItems.forEachIndexed { idx, item ->
                                            Divider()
                                            Row(
                                                modifier = Modifier.padding(vertical = 6.dp, horizontal = 4.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                TableCell(text = "${idx + 1}", width = 50.dp)
                                                TableCell(text = item.description, width = 180.dp, isBold = true)
                                                TableCell(text = item.specification, width = 160.dp)
                                                TableCell(text = item.make, width = 100.dp)
                                                TableCell(text = item.unit, width = 50.dp)

                                                // Interactive Quantity with Traceability Chip!
                                                Box(
                                                    modifier = Modifier
                                                        .width(90.dp)
                                                        .clickable { selectedTraceabilityItem = item }
                                                ) {
                                                    Surface(
                                                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f),
                                                        shape = MaterialTheme.shapes.extraSmall
                                                    ) {
                                                        Row(
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                                            verticalAlignment = Alignment.CenterVertically
                                                        ) {
                                                            Text(
                                                                text = "${item.quantity}",
                                                                style = MaterialTheme.typography.labelSmall,
                                                                fontWeight = FontWeight.Bold,
                                                                color = MaterialTheme.colorScheme.primary
                                                            )
                                                            Spacer(modifier = Modifier.width(2.dp))
                                                            Icon(Icons.Default.Info, contentDescription = "Trace", modifier = Modifier.size(12.dp), tint = MaterialTheme.colorScheme.primary)
                                                        }
                                                    }
                                                }

                                                TableCell(text = String.format("%.2f", item.rate), width = 80.dp)
                                                TableCell(text = String.format("%.2f", item.quantity * item.rate), width = 90.dp, isBold = true)

                                                Row(modifier = Modifier.width(80.dp)) {
                                                    IconButton(onClick = { editingItem = item }, modifier = Modifier.size(32.dp)) {
                                                        Icon(Icons.Default.Edit, contentDescription = "Edit", modifier = Modifier.size(16.dp))
                                                    }
                                                    IconButton(onClick = { viewModel.deleteBoqItem(item) }, modifier = Modifier.size(32.dp)) {
                                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            item {
                EngineeringDisclaimerCard()
            }
        }
    }

    if (selectedTraceabilityItem != null) {
        CalculationTraceabilityDialog(
            boqItem = selectedTraceabilityItem!!,
            onDismiss = { selectedTraceabilityItem = null }
        )
    }

    if (editingItem != null) {
        BoqEditDialog(
            item = editingItem!!,
            onDismiss = { editingItem = null },
            onSave = { updated ->
                viewModel.updateBoqItem(updated)
                editingItem = null
            }
        )
    }

    if (showAddItemDialog) {
        BoqEditDialog(
            item = BoqItemEntity(
                projectId = project!!.id,
                category = "ACCESSORIES",
                description = "",
                specification = "",
                make = "Standard",
                unit = "No",
                quantity = 1.0,
                rate = 50.0,
                isCustom = true
            ),
            onDismiss = { showAddItemDialog = false },
            onSave = { newItem ->
                viewModel.addCustomBoqItem(newItem)
                showAddItemDialog = false
            }
        )
    }
}

@Composable
fun TableCell(
    text: String,
    width: androidx.compose.ui.unit.Dp,
    isHeader: Boolean = false,
    isBold: Boolean = false
) {
    Text(
        text = text,
        modifier = Modifier.width(width),
        style = if (isHeader) MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                else MaterialTheme.typography.bodySmall.copy(fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal),
        fontSize = 11.sp,
        maxLines = 2
    )
}

@Composable
fun BoqEditDialog(
    item: BoqItemEntity,
    onDismiss: () -> Unit,
    onSave: (BoqItemEntity) -> Unit
) {
    var description by remember { mutableStateOf(item.description) }
    var specification by remember { mutableStateOf(item.specification) }
    var make by remember { mutableStateOf(item.make) }
    var unit by remember { mutableStateOf(item.unit) }
    var qtyStr by remember { mutableStateOf(item.quantity.toString()) }
    var rateStr by remember { mutableStateOf(item.rate.toString()) }
    var remarks by remember { mutableStateOf(item.remarks) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (item.id == 0L) "Add Custom BOQ Item" else "Edit Item (${item.description})") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = specification,
                    onValueChange = { specification = it },
                    label = { Text("Specification") },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = make,
                        onValueChange = { make = it },
                        label = { Text("Make") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = unit,
                        onValueChange = { unit = it },
                        label = { Text("Unit") },
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = qtyStr,
                        onValueChange = { qtyStr = it },
                        label = { Text("Quantity") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = rateStr,
                        onValueChange = { rateStr = it },
                        label = { Text("Unit Rate ($)") },
                        modifier = Modifier.weight(1f)
                    )
                }
                OutlinedTextField(
                    value = remarks,
                    onValueChange = { remarks = it },
                    label = { Text("Remarks") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val updated = item.copy(
                        description = description,
                        specification = specification,
                        make = make,
                        unit = unit,
                        quantity = qtyStr.toDoubleOrNull() ?: item.quantity,
                        rate = rateStr.toDoubleOrNull() ?: item.rate,
                        remarks = remarks
                    )
                    onSave(updated)
                }
            ) {
                Text("Save Changes")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
