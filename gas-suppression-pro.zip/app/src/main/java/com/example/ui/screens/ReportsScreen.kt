package com.example.ui.screens

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.calculations.CO2Engine
import com.example.calculations.IG541Engine
import com.example.calculations.UnitConversion
import com.example.ui.components.EngineeringDisclaimerCard
import com.example.ui.viewmodel.GasSuppressionViewModel

@Composable
fun ReportsScreen(
    viewModel: GasSuppressionViewModel,
    onNavigate: (String) -> Unit
) {
    val context = LocalContext.current
    val project by viewModel.selectedProject.collectAsState()
    val rooms by viewModel.roomsForSelectedProject.collectAsState()
    val boqItems by viewModel.boqForSelectedProject.collectAsState()

    val subtotal = boqItems.sumOf { it.quantity * it.rate }
    val gstRate = (project?.gstPercentage ?: 18.0) / 100.0
    val gstAmount = subtotal * gstRate
    val grandTotal = subtotal + gstAmount

    if (project == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Please select or create a project first.", style = MaterialTheme.typography.titleMedium)
        }
        return
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Report Action Toolbar
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Technical Offer & Report Generator", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("Formatted Document for Client Submission", style = MaterialTheme.typography.bodySmall)
                    }
                    Button(
                        onClick = {
                            Toast.makeText(context, "Exporting Technical Offer PDF & Excel Summary...", Toast.LENGTH_LONG).show()
                        }
                    ) {
                        Icon(Icons.Default.Download, contentDescription = "Export")
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Export Offer")
                    }
                }
            }
        }

        // REPORT COVER PAGE CARD
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("TECHNICAL & FINANCIAL OFFER", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, letterSpacing = 2.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("GAS SUPPRESSION SYSTEM DESIGN & BOQ", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                    Spacer(modifier = Modifier.height(12.dp))
                    Divider()
                    Spacer(modifier = Modifier.height(12.dp))

                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        ReportFieldRow("Project Name:", project!!.projectName)
                        ReportFieldRow("Project Code / ID:", project!!.projectCode)
                        ReportFieldRow("Client:", project!!.client)
                        ReportFieldRow("Consultant:", project!!.consultant)
                        ReportFieldRow("Contractor:", project!!.contractor)
                        ReportFieldRow("Location:", project!!.location)
                        ReportFieldRow("Project Number:", project!!.projectNumber)
                        ReportFieldRow("Revision:", project!!.revision)
                        ReportFieldRow("Date:", project!!.date)
                    }
                }
            }
        }

        // PROTECTED ROOMS & CALCULATIONS
        item {
            Text("PROTECTED ROOMS & DESIGN SUMMARY", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }

        items(rooms) { room ->
            val isCo2 = room.systemType.equals("CO2", ignoreCase = true)
            val area = UnitConversion.calculateArea(room.length, room.width, room.unit)
            val volume = UnitConversion.calculateVolume(room.length, room.width, room.height, room.unit)

            val (agentQty, unitStr, cylCount, nozzleCount) = if (isCo2) {
                val res = CO2Engine.calculate(room.length, room.width, room.height, room.unit, room.hazardType, room.designConcentration, room.temperature, room.cylinderCapacity)
                Tuple4(res.totalProvidedGasKg, "kg", res.cylinderCount, res.nozzleCount)
            } else {
                val res = IG541Engine.calculate(room.length, room.width, room.height, room.unit, room.designConcentration, room.temperature, room.cylinderPressure, room.cylinderVolumeLiters)
                Tuple4(res.totalProvidedGasM3, "m³", res.cylinderCount, res.nozzleCount)
            }

            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Enclosure: ${room.roomName} (${room.systemType.uppercase()})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Dimensions: ${room.length} × ${room.width} × ${room.height} ${room.unit}", style = MaterialTheme.typography.bodySmall)
                        Text("Vol: ${UnitConversion.formatDouble(volume, 2)} m³", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Design Concentration: ${room.designConcentration}%", style = MaterialTheme.typography.bodySmall)
                        Text("Agent Provided: ${UnitConversion.formatDouble(agentQty, 1)} $unitStr", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Cylinders: $cylCount Nos", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Text("Nozzles: $nozzleCount Nos", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }

        // FINANCIAL SUMMARY TABLE
        item {
            Text("FINANCIAL SUMMARY & TAX BREAKDOWN", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Equipment Subtotal Amount:")
                        Text("$ ${String.format("%.2f", subtotal)}", fontWeight = FontWeight.Bold)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("GST Tax (${project!!.gstPercentage}%):")
                        Text("$ ${String.format("%.2f", gstAmount)}", fontWeight = FontWeight.Bold)
                    }
                    Divider()
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Grand Total Commercial Offer:", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("$ ${String.format("%.2f", grandTotal)}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }

        // SIGNATURE APPROVAL BLOCK
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text("ENGINEERING SIGNATURE & APPROVAL BLOCK", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        SignatureBox(title = "PREPARED BY", name = project!!.preparedBy)
                        SignatureBox(title = "CHECKED BY", name = project!!.checkedBy)
                        SignatureBox(title = "APPROVED BY", name = project!!.approvedBy)
                    }
                }
            }
        }

        item {
            EngineeringDisclaimerCard()
        }
    }
}

@Composable
fun ReportFieldRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value.ifBlank { "-" }, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun SignatureBox(title: String, name: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .width(100.dp)
                .height(40.dp)
                .background(MaterialTheme.colorScheme.surfaceVariant, MaterialTheme.shapes.extraSmall),
            contentAlignment = Alignment.Center
        ) {
            Text("[ SIGNED ]", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(title, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
        Text(name.ifBlank { "Designated Engineer" }, style = MaterialTheme.typography.bodySmall, fontSize = 10.sp)
    }
}
