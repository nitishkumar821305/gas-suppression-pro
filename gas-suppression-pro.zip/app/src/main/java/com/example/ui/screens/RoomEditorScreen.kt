package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.calculations.UnitConversion
import com.example.calculations.ValidationEngine
import com.example.data.model.RoomEntity
import com.example.ui.navigation.Screen
import com.example.ui.viewmodel.GasSuppressionViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoomEditorScreen(
    viewModel: GasSuppressionViewModel,
    onNavigate: (String) -> Unit
) {
    val project by viewModel.selectedProject.collectAsState()
    val rooms by viewModel.roomsForSelectedProject.collectAsState()
    val selectedRoomId by viewModel.selectedRoomId.collectAsState()

    val roomToEdit = rooms.find { it.id == selectedRoomId }

    var roomName by remember(roomToEdit) { mutableStateOf(roomToEdit?.roomName ?: "CONTROL ROOM") }
    var systemType by remember(roomToEdit) { mutableStateOf(roomToEdit?.systemType ?: "CO2") }
    var unit by remember(roomToEdit) { mutableStateOf(roomToEdit?.unit ?: "metre") }

    var lengthStr by remember(roomToEdit) { mutableStateOf(roomToEdit?.length?.toString() ?: "10.0") }
    var widthStr by remember(roomToEdit) { mutableStateOf(roomToEdit?.width?.toString() ?: "8.0") }
    var heightStr by remember(roomToEdit) { mutableStateOf(roomToEdit?.height?.toString() ?: "4.0") }

    var hazardType by remember(roomToEdit) { mutableStateOf(roomToEdit?.hazardType ?: "Electrical") }
    var designConcStr by remember(roomToEdit) { mutableStateOf(roomToEdit?.designConcentration?.toString() ?: if (systemType == "CO2") "50.0" else "38.0") }
    var tempCStr by remember(roomToEdit) { mutableStateOf(roomToEdit?.temperature?.toString() ?: "20.0") }

    var cylinderCapStr by remember(roomToEdit) { mutableStateOf(roomToEdit?.cylinderCapacity?.toString() ?: "45.0") }
    var cylinderPressureInt by remember(roomToEdit) { mutableIntStateOf(roomToEdit?.cylinderPressure ?: 200) }
    var cylinderVolLiters by remember(roomToEdit) { mutableDoubleStateOf(roomToEdit?.cylinderVolumeLiters ?: 80.0) }

    var remarks by remember(roomToEdit) { mutableStateOf(roomToEdit?.remarks ?: "") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    // Live calculations
    val lengthVal = lengthStr.toDoubleOrNull() ?: 0.0
    val widthVal = widthStr.toDoubleOrNull() ?: 0.0
    val heightVal = heightStr.toDoubleOrNull() ?: 0.0

    val areaM2 = UnitConversion.calculateArea(lengthVal, widthVal, unit)
    val volumeM3 = UnitConversion.calculateVolume(lengthVal, widthVal, heightVal, unit)

    if (project == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Please select or create a project first.")
        }
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (roomToEdit == null) "Add Protected Room" else "Edit Room (${roomToEdit.roomName})") },
                navigationIcon = {
                    IconButton(onClick = { onNavigate(Screen.ProjectDetail.route) }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (errorMessage != null) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Error, contentDescription = "Error", tint = MaterialTheme.colorScheme.error)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(errorMessage!!, color = MaterialTheme.colorScheme.onErrorContainer, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }

            // System Type Selector
            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Gas Suppression System Selection", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FilterChip(
                                selected = systemType.equals("CO2", ignoreCase = true),
                                onClick = {
                                    systemType = "CO2"
                                    designConcStr = "50.0"
                                    cylinderCapStr = "45.0"
                                },
                                label = { Text("CO₂ FIRE SUPPRESSION", fontWeight = FontWeight.Bold) },
                                leadingIcon = { Icon(Icons.Default.Co2, contentDescription = "CO2") },
                                modifier = Modifier.weight(1f)
                            )
                            FilterChip(
                                selected = systemType.equals("IG541", ignoreCase = true),
                                onClick = {
                                    systemType = "IG541"
                                    designConcStr = "38.0"
                                },
                                label = { Text("IG-541 INERGEN", fontWeight = FontWeight.Bold) },
                                leadingIcon = { Icon(Icons.Default.Air, contentDescription = "IG541") },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // Room Identity & Dimensions
            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Room Geometry & Unit Specification", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                        OutlinedTextField(
                            value = roomName,
                            onValueChange = { roomName = it },
                            label = { Text("Room Name (e.g. CONTROL ROOM, BATTERY ROOM)") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        Text("Unit System:", style = MaterialTheme.typography.labelLarge)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("metre", "feet", "mm").forEach { unitOption ->
                                FilterChip(
                                    selected = unit.equals(unitOption, ignoreCase = true),
                                    onClick = { unit = unitOption },
                                    label = { Text(unitOption.replaceFirstChar { it.uppercase() }) }
                                )
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = lengthStr,
                                onValueChange = { lengthStr = it },
                                label = { Text("Length ($unit)") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = widthStr,
                                onValueChange = { widthStr = it },
                                label = { Text("Width ($unit)") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = heightStr,
                                onValueChange = { heightStr = it },
                                label = { Text("Height ($unit)") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                        }

                        // Live Area & Volume Summary
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                            shape = MaterialTheme.shapes.small,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceAround
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Calculated Area", style = MaterialTheme.typography.labelSmall)
                                    Text("${UnitConversion.formatDouble(areaM2, 2)} m²", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                }
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Calculated Volume", style = MaterialTheme.typography.labelSmall)
                                    Text("${UnitConversion.formatDouble(volumeM3, 2)} m³", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    }
                }
            }

            // System Engineering Parameters
            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Engineering & Design Parameters", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                        if (systemType.equals("CO2", ignoreCase = true)) {
                            Text("Hazard Type:")
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("Electrical", "Generator", "Surface", "Deep Seated").forEach { hazard ->
                                    FilterChip(
                                        selected = hazardType.equals(hazard, ignoreCase = true),
                                        onClick = {
                                            hazardType = hazard
                                            designConcStr = if (hazard == "Electrical" || hazard == "Deep Seated") "50.0" else "34.0"
                                        },
                                        label = { Text(hazard) }
                                    )
                                }
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = designConcStr,
                                    onValueChange = { designConcStr = it },
                                    label = { Text("Design Concentration (%)") },
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    value = tempCStr,
                                    onValueChange = { tempCStr = it },
                                    label = { Text("Design Temp (°C)") },
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                            }

                            Text("Cylinder Capacity Option:")
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("45.0", "68.0").forEach { cap ->
                                    FilterChip(
                                        selected = cylinderCapStr == cap,
                                        onClick = { cylinderCapStr = cap },
                                        label = { Text("$cap kg CO₂ Cylinder") }
                                    )
                                }
                            }
                        } else {
                            // IG-541 System Parameters
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = designConcStr,
                                    onValueChange = { designConcStr = it },
                                    label = { Text("Design Concentration (%)") },
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    value = tempCStr,
                                    onValueChange = { tempCStr = it },
                                    label = { Text("Design Temp (°C)") },
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                            }

                            Text("Cylinder Pressure Rating:")
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf(200, 300).forEach { press ->
                                    FilterChip(
                                        selected = cylinderPressureInt == press,
                                        onClick = { cylinderPressureInt = press },
                                        label = { Text("$press Bar") }
                                    )
                                }
                            }

                            Text("Cylinder Water Capacity:")
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf(80.0, 140.0).forEach { vol ->
                                    FilterChip(
                                        selected = cylinderVolLiters == vol,
                                        onClick = { cylinderVolLiters = vol },
                                        label = { Text("${vol.toInt()} Liters") }
                                    )
                                }
                            }
                        }

                        OutlinedTextField(
                            value = remarks,
                            onValueChange = { remarks = it },
                            label = { Text("Engineering Remarks") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            // Save Actions
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { onNavigate(Screen.ProjectDetail.route) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Cancel")
                    }
                    Button(
                        onClick = {
                            val valRes = ValidationEngine.validateRoomInputs(lengthStr, widthStr, heightStr, designConcStr)
                            if (!valRes.isValid) {
                                errorMessage = valRes.errorMessage
                            } else {
                                val newRoom = RoomEntity(
                                    id = roomToEdit?.id ?: 0,
                                    projectId = project!!.id,
                                    roomName = roomName,
                                    systemType = systemType,
                                    length = lengthVal,
                                    width = widthVal,
                                    height = heightVal,
                                    unit = unit,
                                    hazardType = hazardType,
                                    designConcentration = designConcStr.toDoubleOrNull() ?: 40.0,
                                    temperature = tempCStr.toDoubleOrNull() ?: 20.0,
                                    cylinderCapacity = cylinderCapStr.toDoubleOrNull() ?: 45.0,
                                    cylinderPressure = cylinderPressureInt,
                                    cylinderVolumeLiters = cylinderVolLiters,
                                    remarks = remarks
                                )
                                viewModel.saveRoom(newRoom) {
                                    onNavigate(Screen.DesignCalculation.route)
                                }
                            }
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Save, contentDescription = "Save")
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Calculate & Save BOQ")
                    }
                }
            }
        }
    }
}
