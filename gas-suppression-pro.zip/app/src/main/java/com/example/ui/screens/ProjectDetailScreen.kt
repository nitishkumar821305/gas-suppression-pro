package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.calculations.CO2Engine
import com.example.calculations.IG541Engine
import com.example.calculations.UnitConversion
import com.example.data.model.RoomEntity
import com.example.ui.navigation.Screen
import com.example.ui.viewmodel.GasSuppressionViewModel

@Composable
fun ProjectDetailScreen(
    viewModel: GasSuppressionViewModel,
    onNavigate: (String) -> Unit
) {
    val project by viewModel.selectedProject.collectAsState()
    val rooms by viewModel.roomsForSelectedProject.collectAsState()
    val boqItems by viewModel.boqForSelectedProject.collectAsState()

    var showEditProjectDialog by remember { mutableStateOf(false) }

    val totalSubtotal = boqItems.sumOf { it.quantity * it.rate }
    val totalGst = totalSubtotal * ((project?.gstPercentage ?: 18.0) / 100.0)
    val grandTotal = totalSubtotal + totalGst

    if (project == null) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("No project selected", style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(12.dp))
                Button(onClick = { onNavigate(Screen.Projects.route) }) {
                    Text("Select or Create a Project")
                }
            }
        }
        return
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Project Overview Card
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = project!!.projectName,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Code: ${project!!.projectCode} | Rev: ${project!!.revision}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        IconButton(onClick = { showEditProjectDialog = true }) {
                            Icon(Icons.Default.Edit, contentDescription = "Edit Project")
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Divider()
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Client: ${project!!.client}", style = MaterialTheme.typography.bodyMedium)
                            Text("Consultant: ${project!!.consultant}", style = MaterialTheme.typography.bodyMedium)
                            Text("Contractor: ${project!!.contractor}", style = MaterialTheme.typography.bodyMedium)
                        }
                        Column {
                            Text("Location: ${project!!.location}", style = MaterialTheme.typography.bodyMedium)
                            Text("Date: ${project!!.date}", style = MaterialTheme.typography.bodyMedium)
                            Text("Project #: ${project!!.projectNumber}", style = MaterialTheme.typography.bodyMedium)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                viewModel.selectRoom(null)
                                onNavigate(Screen.RoomEditor.route)
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Add Room")
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Add Room")
                        }
                        OutlinedButton(
                            onClick = { onNavigate(Screen.Boq.route) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.ReceiptLong, contentDescription = "BOQ")
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Project BOQ")
                        }
                    }
                }
            }
        }

        // Financial Summary Banner
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Project Financial Estimation",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            text = "Grand Total: $ ${String.format("%.2f", grandTotal)}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("Subtotal: $ ${String.format("%.2f", totalSubtotal)}", style = MaterialTheme.typography.bodySmall)
                        Text("GST (${project!!.gstPercentage}%): $ ${String.format("%.2f", totalGst)}", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }

        // Protected Rooms Section
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Protected Rooms (${rooms.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                TextButton(
                    onClick = {
                        viewModel.selectRoom(null)
                        onNavigate(Screen.RoomEditor.route)
                    }
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add")
                    Spacer(modifier = Modifier.width(2.dp))
                    Text("Add Room")
                }
            }
        }

        if (rooms.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.MeetingRoom,
                            contentDescription = "No Rooms",
                            modifier = Modifier.size(48.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "No protected rooms defined for this project",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = {
                                viewModel.selectRoom(null)
                                onNavigate(Screen.RoomEditor.route)
                            }
                        ) {
                            Text("Add First Protected Room")
                        }
                    }
                }
            }
        } else {
            items(rooms) { room ->
                RoomSummaryCard(
                    room = room,
                    onEdit = {
                        viewModel.selectRoom(room.id)
                        onNavigate(Screen.RoomEditor.route)
                    },
                    onCalculate = {
                        viewModel.selectRoom(room.id)
                        onNavigate(Screen.DesignCalculation.route)
                    },
                    onDelete = {
                        viewModel.deleteRoom(room)
                    }
                )
            }
        }
    }

    if (showEditProjectDialog) {
        ProjectFormDialog(
            project = project,
            onDismiss = { showEditProjectDialog = false },
            onSave = { updated ->
                viewModel.updateProject(updated)
                showEditProjectDialog = false
            }
        )
    }
}

@Composable
fun RoomSummaryCard(
    room: RoomEntity,
    onEdit: () -> Unit,
    onCalculate: () -> Unit,
    onDelete: () -> Unit
) {
    val area = UnitConversion.calculateArea(room.length, room.width, room.unit)
    val volume = UnitConversion.calculateVolume(room.length, room.width, room.height, room.unit)

    val (cylCount, agentAmount, unitStr, nozzleCount) = if (room.systemType.equals("CO2", ignoreCase = true)) {
        val res = CO2Engine.calculate(
            length = room.length, width = room.width, height = room.height,
            unit = room.unit, hazardType = room.hazardType,
            designConcentration = room.designConcentration, tempC = room.temperature,
            cylinderCapacityKg = room.cylinderCapacity
        )
        Tuple4(res.cylinderCount, res.totalProvidedGasKg, "kg", res.nozzleCount)
    } else {
        val res = IG541Engine.calculate(
            length = room.length, width = room.width, height = room.height,
            unit = room.unit, designConcentration = room.designConcentration,
            tempC = room.temperature, cylinderPressureBar = room.cylinderPressure,
            cylinderVolumeLiters = room.cylinderVolumeLiters
        )
        Tuple4(res.cylinderCount, res.totalProvidedGasM3, "m³", res.nozzleCount)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = room.roomName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Dimensions: ${room.length} × ${room.width} × ${room.height} ${room.unit}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                SuggestionChip(
                    onClick = {},
                    label = { Text(room.systemType.uppercase(), fontWeight = FontWeight.Bold) },
                    colors = SuggestionChipDefaults.suggestionChipColors(
                        containerColor = if (room.systemType.equals("CO2", ignoreCase = true))
                            MaterialTheme.colorScheme.primaryContainer
                        else MaterialTheme.colorScheme.secondaryContainer
                    )
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            Divider()
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                MetricItem(label = "Floor Area", value = "${UnitConversion.formatDouble(area, 2)} m²")
                MetricItem(label = "Protected Vol.", value = "${UnitConversion.formatDouble(volume, 2)} m³")
                MetricItem(label = "Cylinders", value = "$cylCount Nos")
                MetricItem(label = "Required Agent", value = "${UnitConversion.formatDouble(agentAmount, 1)} $unitStr")
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                }
                IconButton(onClick = onEdit) {
                    Icon(Icons.Default.Edit, contentDescription = "Edit Room")
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(onClick = onCalculate) {
                    Icon(Icons.Default.Calculate, contentDescription = "Design")
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Design Calc")
                }
            }
        }
    }
}

@Composable
fun MetricItem(label: String, value: String) {
    Column {
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
    }
}

data class Tuple4<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
