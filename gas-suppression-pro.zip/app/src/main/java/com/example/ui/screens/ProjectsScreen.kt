package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

import com.example.data.model.ProjectEntity
import com.example.ui.navigation.Screen
import com.example.ui.viewmodel.GasSuppressionViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectsScreen(
    viewModel: GasSuppressionViewModel,
    onNavigate: (String) -> Unit
) {
    val projects by viewModel.allProjects.collectAsState()
    val selectedProject by viewModel.selectedProject.collectAsState()

    var showCreateDialog by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }

    val filteredProjects = projects.filter {
        it.projectName.contains(searchQuery, ignoreCase = true) ||
        it.client.contains(searchQuery, ignoreCase = true) ||
        it.projectCode.contains(searchQuery, ignoreCase = true)
    }

    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showCreateDialog = true },
                icon = { Icon(Icons.Default.Add, contentDescription = "Add Project") },
                text = { Text("New Project") },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "Project Management",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("Search Projects") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                trailingIcon = if (searchQuery.isNotEmpty()) {
                    { IconButton(onClick = { searchQuery = "" }) { Icon(Icons.Default.Clear, contentDescription = "Clear") } }
                } else null,
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            if (filteredProjects.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.FolderOff,
                            contentDescription = "Empty",
                            modifier = Modifier.size(64.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = if (searchQuery.isEmpty()) "No projects found in database" else "No matching projects",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(filteredProjects) { proj ->
                        val isSelected = proj.id == selectedProject?.id
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected)
                                    MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)
                                else MaterialTheme.colorScheme.surface
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.selectProject(proj.id)
                                    onNavigate(Screen.ProjectDetail.route)
                                }
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = proj.projectName,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "ID: ${proj.projectCode} | No: ${proj.projectNumber}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.secondary
                                        )
                                    }
                                    AssistChip(
                                        onClick = { },
                                        label = { Text("Rev ${proj.revision}") }
                                    )
                                }

                                Spacer(modifier = Modifier.height(8.dp))
                                Divider()
                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Client: ${proj.client}", style = MaterialTheme.typography.bodySmall)
                                    Text("Consultant: ${proj.consultant}", style = MaterialTheme.typography.bodySmall)
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Contractor: ${proj.contractor}", style = MaterialTheme.typography.bodySmall)
                                    Text("Date: ${proj.date}", style = MaterialTheme.typography.bodySmall)
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    IconButton(onClick = { viewModel.duplicateProject(proj) }) {
                                        Icon(Icons.Default.ContentCopy, contentDescription = "Duplicate")
                                    }
                                    IconButton(onClick = { viewModel.deleteProject(proj) }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Button(
                                        onClick = {
                                            viewModel.selectProject(proj.id)
                                            onNavigate(Screen.ProjectDetail.route)
                                        }
                                    ) {
                                        Text("Open Rooms & BOQ")
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Icon(Icons.Default.ArrowForward, contentDescription = "Open")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        ProjectFormDialog(
            project = null,
            onDismiss = { showCreateDialog = false },
            onSave = { newProj ->
                viewModel.createProject(newProj) { projId ->
                    viewModel.selectProject(projId)
                    showCreateDialog = false
                    onNavigate(Screen.ProjectDetail.route)
                }
            }
        )
    }
}

@Composable
fun ProjectFormDialog(
    project: ProjectEntity?,
    onDismiss: () -> Unit,
    onSave: (ProjectEntity) -> Unit
) {
    var projectCode by remember { mutableStateOf(project?.projectCode ?: "PRJ-${System.currentTimeMillis() % 10000}") }
    var projectName by remember { mutableStateOf(project?.projectName ?: "") }
    var client by remember { mutableStateOf(project?.client ?: "") }
    var consultant by remember { mutableStateOf(project?.consultant ?: "") }
    var contractor by remember { mutableStateOf(project?.contractor ?: "") }
    var location by remember { mutableStateOf(project?.location ?: "") }
    var projectNumber by remember { mutableStateOf(project?.projectNumber ?: "FO-2026-01") }
    var revision by remember { mutableStateOf(project?.revision ?: "R0") }
    var date by remember { mutableStateOf(project?.date ?: "2026-02-20") }
    var preparedBy by remember { mutableStateOf(project?.preparedBy ?: "Design Engineer") }
    var checkedBy by remember { mutableStateOf(project?.checkedBy ?: "Lead Engineer") }
    var approvedBy by remember { mutableStateOf(project?.approvedBy ?: "Technical Director") }
    var remarks by remember { mutableStateOf(project?.remarks ?: "") }

    var errorMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (project == null) "Create New Project" else "Edit Project Details") },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (errorMsg != null) {
                    item {
                        Text(
                            text = errorMsg!!,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
                item {
                    OutlinedTextField(
                        value = projectName,
                        onValueChange = { projectName = it },
                        label = { Text("Project Name *") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = projectCode,
                            onValueChange = { projectCode = it },
                            label = { Text("Project ID / Code") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = projectNumber,
                            onValueChange = { projectNumber = it },
                            label = { Text("Project Number") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                }
                item {
                    OutlinedTextField(
                        value = client,
                        onValueChange = { client = it },
                        label = { Text("Client Name") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = consultant,
                            onValueChange = { consultant = it },
                            label = { Text("Consultant") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = contractor,
                            onValueChange = { contractor = it },
                            label = { Text("Contractor") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = location,
                            onValueChange = { location = it },
                            label = { Text("Location") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = revision,
                            onValueChange = { revision = it },
                            label = { Text("Revision") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = date,
                            onValueChange = { date = it },
                            label = { Text("Date") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = preparedBy,
                            onValueChange = { preparedBy = it },
                            label = { Text("Prepared By") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = checkedBy,
                            onValueChange = { checkedBy = it },
                            label = { Text("Checked By") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = approvedBy,
                            onValueChange = { approvedBy = it },
                            label = { Text("Approved By") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                }
                item {
                    OutlinedTextField(
                        value = remarks,
                        onValueChange = { remarks = it },
                        label = { Text("Remarks") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (projectName.isBlank()) {
                        errorMsg = "Project Name cannot be empty."
                    } else {
                        val newProj = ProjectEntity(
                            id = project?.id ?: 0,
                            projectCode = projectCode,
                            projectName = projectName,
                            client = client,
                            consultant = consultant,
                            contractor = contractor,
                            location = location,
                            projectNumber = projectNumber,
                            revision = revision,
                            date = date,
                            preparedBy = preparedBy,
                            checkedBy = checkedBy,
                            approvedBy = approvedBy,
                            remarks = remarks
                        )
                        onSave(newProj)
                    }
                }
            ) {
                Text(if (project == null) "Create Project" else "Save Changes")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
