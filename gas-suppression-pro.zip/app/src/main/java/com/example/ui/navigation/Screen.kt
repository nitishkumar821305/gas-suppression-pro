package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(val route: String, val title: String, val icon: ImageVector) {
    object Dashboard : Screen("dashboard", "Dashboard", Icons.Default.Dashboard)
    object Projects : Screen("projects", "Projects", Icons.Default.Folder)
    object ProjectDetail : Screen("project_detail", "Project Details", Icons.Default.Assignment)
    object RoomEditor : Screen("room_editor", "Room Editor", Icons.Default.MeetingRoom)
    object DesignCalculation : Screen("design_calc", "Design Engine", Icons.Default.Calculate)
    object Boq : Screen("boq", "BOQ Generator", Icons.Default.ReceiptLong)
    object ExcelMapping : Screen("excel_mapping", "Excel Reference & Test", Icons.Default.TableChart)
    object Reports : Screen("reports", "Reports & PDF", Icons.Default.Description)
    object Settings : Screen("settings", "Settings", Icons.Default.Settings)
}

val sidebarScreens = listOf(
    Screen.Dashboard,
    Screen.Projects,
    Screen.DesignCalculation,
    Screen.Boq,
    Screen.ExcelMapping,
    Screen.Reports,
    Screen.Settings
)
