package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Immersive UI - Dark Palette (Primary Target)
val ImmersiveBackground = Color(0xFF111318)
val ImmersiveSurface = Color(0xFF1D1B20)
val ImmersiveSurfaceVariant = Color(0xFF2B2930)
val ImmersivePrimary = Color(0xFFD0BCFF)
val ImmersiveOnPrimary = Color(0xFF381E72)
val ImmersivePrimaryContainer = Color(0xFF4F378B)
val ImmersiveOnPrimaryContainer = Color(0xFFEADDFF)

val ImmersiveSecondary = Color(0xFFCCC2DC)
val ImmersiveOnSecondary = Color(0xFF332D41)
val ImmersiveSecondaryContainer = Color(0xFF4A4458)

val ImmersiveTextPrimary = Color(0xFFE2E2E6)
val ImmersiveTextSecondary = Color(0xFF919094)

val ImmersiveBorder = Color(0xFF49454F)
val ImmersiveDivider = Color(0xFF36343B)

// Status Colors
val PassGreen = Color(0xFF81C784)
val FailRed = Color(0xFFF2B8B5)
val WarningOrange = Color(0xFFFFB74D)
val InfoBlue = Color(0xFF64B5F6)

// Legacy alias definitions for light theme support
val PrimaryBlue = Color(0xFF6750A4)
val SecondaryCyan = Color(0xFF625B71)
val TertiaryAmber = Color(0xFF7D5260)
val BackgroundLight = Color(0xFFFEF7FF)
val SurfaceLight = Color(0xFFF7F2FA)
val SurfaceVariantLight = Color(0xFFE7E0EC)
val TextPrimaryLight = Color(0xFF1D1B20)
val TextSecondaryLight = Color(0xFF49454F)

