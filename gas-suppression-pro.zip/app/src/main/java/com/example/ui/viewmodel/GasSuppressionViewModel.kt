package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AppDatabase
import com.example.data.model.BoqItemEntity
import com.example.data.model.ProjectEntity
import com.example.data.model.RoomEntity
import com.example.data.model.SettingsEntity
import com.example.data.repository.GasSuppressionRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class GasSuppressionViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: GasSuppressionRepository
    val allProjects: StateFlow<List<ProjectEntity>>
    val settings: StateFlow<SettingsEntity>

    private val _selectedProjectId = MutableStateFlow<Long?>(null)
    val selectedProjectId: StateFlow<Long?> = _selectedProjectId.asStateFlow()

    private val _selectedRoomId = MutableStateFlow<Long?>(null)
    val selectedRoomId: StateFlow<Long?> = _selectedRoomId.asStateFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val selectedProject: StateFlow<ProjectEntity?> = _selectedProjectId
        .flatMapLatest { id ->
            if (id == null || id == 0L) flowOf(null)
            else repository.allProjects.map { list -> list.find { it.id == id } }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    @OptIn(ExperimentalCoroutinesApi::class)
    val roomsForSelectedProject: StateFlow<List<RoomEntity>> = _selectedProjectId
        .flatMapLatest { id ->
            if (id == null || id == 0L) flowOf(emptyList())
            else repository.getRoomsForProject(id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val boqForSelectedProject: StateFlow<List<BoqItemEntity>> = _selectedProjectId
        .flatMapLatest { id ->
            if (id == null || id == 0L) flowOf(emptyList())
            else repository.getBoqItemsForProject(id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        val database = AppDatabase.getDatabase(application)
        repository = GasSuppressionRepository(database)

        allProjects = repository.allProjects
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        settings = repository.settingsFlow
            .map { it ?: SettingsEntity() }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), SettingsEntity())

        // Auto select first project when available if none selected
        viewModelScope.launch {
            allProjects.collect { projects ->
                if (_selectedProjectId.value == null && projects.isNotEmpty()) {
                    _selectedProjectId.value = projects.first().id
                }
            }
        }
    }

    fun selectProject(projectId: Long) {
        _selectedProjectId.value = projectId
        _selectedRoomId.value = null
    }

    fun selectRoom(roomId: Long?) {
        _selectedRoomId.value = roomId
    }

    fun createProject(project: ProjectEntity, onCreated: (Long) -> Unit = {}) {
        viewModelScope.launch {
            val id = repository.createProject(project)
            _selectedProjectId.value = id
            onCreated(id)
        }
    }

    fun updateProject(project: ProjectEntity) {
        viewModelScope.launch {
            repository.updateProject(project)
        }
    }

    fun deleteProject(project: ProjectEntity) {
        viewModelScope.launch {
            repository.deleteProject(project)
            if (_selectedProjectId.value == project.id) {
                _selectedProjectId.value = null
                _selectedRoomId.value = null
            }
        }
    }

    fun duplicateProject(project: ProjectEntity) {
        viewModelScope.launch {
            val newId = repository.duplicateProject(project)
            _selectedProjectId.value = newId
        }
    }

    fun saveRoom(room: RoomEntity, onSaved: (Long) -> Unit = {}) {
        viewModelScope.launch {
            val roomId = repository.saveRoom(room)
            _selectedRoomId.value = roomId
            onSaved(roomId)
        }
    }

    fun deleteRoom(room: RoomEntity) {
        viewModelScope.launch {
            repository.deleteRoom(room)
            if (_selectedRoomId.value == room.id) {
                _selectedRoomId.value = null
            }
        }
    }

    fun updateBoqItem(item: BoqItemEntity) {
        viewModelScope.launch {
            repository.updateBoqItem(item)
        }
    }

    fun addCustomBoqItem(item: BoqItemEntity) {
        viewModelScope.launch {
            repository.insertBoqItem(item)
        }
    }

    fun deleteBoqItem(item: BoqItemEntity) {
        viewModelScope.launch {
            repository.deleteBoqItem(item)
        }
    }

    fun saveSettings(newSettings: SettingsEntity) {
        viewModelScope.launch {
            repository.saveSettings(newSettings)
        }
    }
}
