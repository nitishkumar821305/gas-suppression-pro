package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.calculations.CO2Engine
import com.example.calculations.CalculationStep
import com.example.calculations.IG541Engine
import com.example.calculations.UnitConversion
import com.example.ui.components.EngineeringDisclaimerCard
import com.example.ui.navigation.Screen
import com.example.ui.viewmodel.GasSuppressionViewModel

@Composable
fun DesignCalculationScreen(
    viewModel: GasSuppressionViewModel,
    onNavigate: (String) -> Unit
) {
    val rooms by viewModel.roomsForSelectedProject.collectAsState()
    val selectedRoomId by viewModel.selectedRoomId.collectAsState()

    val currentRoom = rooms.find { it.id == selectedRoomId } ?: rooms.firstOrNull()

    if (currentRoom == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("No room selected for design calculation.", style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(12.dp))
                Button(onClick = { onNavigate(Screen.ProjectDetail.route) }) {
                    Text("Select or Add Room")
                }
            }
        }
        return
    }

    val isCo2 = currentRoom.systemType.equals("CO2", ignoreCase = true)

    val (steps, cylCount, agentQty, agentUnit, nozzleCount, pipeLength, manifoldSize) = if (isCo2) {
        val res = CO2Engine.calculate(
            length = currentRoom.length,
            width = currentRoom.width,
            height = currentRoom.height,
            unit = currentRoom.unit,
            hazardType = currentRoom.hazardType,
            designConcentration = currentRoom.designConcentration,
            tempC = currentRoom.temperature,
            cylinderCapacityKg = currentRoom.cylinderCapacity
        )
        Tuple7(res.calculationSteps, res.cylinderCount, res.totalProvidedGasKg, "kg", res.nozzleCount, res.pipeLengthMtr, res.manifoldSizeInch)
    } else {
        val res = IG541Engine.calculate(
            length = currentRoom.length,
            width = currentRoom.width,
            height = currentRoom.height,
            unit = currentRoom.unit,
            designConcentration = currentRoom.designConcentration,
            tempC = currentRoom.temperature,
            cylinderPressureBar = currentRoom.cylinderPressure,
            cylinderVolumeLiters = currentRoom.cylinderVolumeLiters
        )
        Tuple7(res.calculationSteps, res.cylinderCount, res.totalProvidedGasM3, "m³", res.nozzleCount, res.pipeLengthMtr, res.manifoldSizeInch)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Room Selector & System Header
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Design Engine: ${currentRoom.roomName}",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "System: ${currentRoom.systemType.uppercase()} FIRE SUPPRESSION",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        IconButton(onClick = { onNavigate(Screen.RoomEditor.route) }) {
                            Icon(Icons.Default.Edit, contentDescription = "Edit Inputs")
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        rooms.forEach { r ->
                            FilterChip(
                                selected = r.id == currentRoom.id,
                                onClick = { viewModel.selectRoom(r.id) },
                                label = { Text(r.roomName) }
                            )
                        }
                    }
                }
            }
        }

        // INPUT Summary Panel
        item {
            Text("1. INPUT PARAMETERS", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(4.dp))
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Dimensions:")
                        Text("${currentRoom.length} × ${currentRoom.width} × ${currentRoom.height} ${currentRoom.unit}", fontWeight = FontWeight.Bold)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Floor Area:")
                        Text("${UnitConversion.formatDouble(UnitConversion.calculateArea(currentRoom.length, currentRoom.width, currentRoom.unit), 2)} m²", fontWeight = FontWeight.Bold)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Protected Volume:")
                        Text("${UnitConversion.formatDouble(UnitConversion.calculateVolume(currentRoom.length, currentRoom.width, currentRoom.height, currentRoom.unit), 2)} m³", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Design Concentration:")
                        Text("${currentRoom.designConcentration}%", fontWeight = FontWeight.Bold)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Design Temp:")
                        Text("${currentRoom.temperature} °C", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // CALCULATION STEPS
        item {
            Text("2. TRANSPARENT CALCULATION ENGINE STEPS", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }

        items(steps) { step ->
            CalculationStepCard(step = step)
        }

        // RESULT SUMMARY & BOQ LINK
        item {
            Text("3. DESIGN RESULT SUMMARY", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(4.dp))
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.6f)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Total Gas Agent Provided:", fontWeight = FontWeight.Medium)
                        Text("${UnitConversion.formatDouble(agentQty, 2)} $agentUnit", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Cylinder Quantity:", fontWeight = FontWeight.Medium)
                        Text("$cylCount Nos", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Nozzles Required:", fontWeight = FontWeight.Medium)
                        Text("$nozzleCount Nos (360°/180° Radial)", fontWeight = FontWeight.Bold)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Collector Manifold Size:", fontWeight = FontWeight.Medium)
                        Text(manifoldSize, fontWeight = FontWeight.Bold)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Seamless Steel Piping:", fontWeight = FontWeight.Medium)
                        Text("${UnitConversion.formatDouble(pipeLength, 1)} Mtr", fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = { onNavigate(Screen.Boq.route) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.ReceiptLong, contentDescription = "BOQ")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("View Generated BOQ & Financial Rates")
                    }
                }
            }
        }

        item {
            EngineeringDisclaimerCard()
        }
    }
}

@Composable
fun CalculationStepCard(step: CalculationStep) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(step.stepName, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = "${step.value} ${step.unit}",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(6.dp))
                    .padding(8.dp)
            ) {
                Text(
                    text = "Formula: ${step.formula}",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(step.explanation, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

data class Tuple7<A, B, C, D, E, F, G>(val first: A, val second: B, val third: C, val fourth: D, val fifth: E, val sixth: F, val seventh: G)
