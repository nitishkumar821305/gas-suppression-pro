package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.SettingsEntity
import com.example.ui.components.EngineeringDisclaimerCard
import com.example.ui.viewmodel.GasSuppressionViewModel

@Composable
fun SettingsScreen(
    viewModel: GasSuppressionViewModel,
    onNavigate: (String) -> Unit
) {
    val context = LocalContext.current
    val currentSettings by viewModel.settings.collectAsState()

    var co2CapStr by remember(currentSettings) { mutableStateOf(currentSettings.co2CylinderCapacityKg.toString()) }
    var igVolStr by remember(currentSettings) { mutableStateOf(currentSettings.ig541CylinderVolumeLiters.toString()) }
    var igPressStr by remember(currentSettings) { mutableStateOf(currentSettings.ig541CylinderPressureBar.toString()) }

    var co2ConcStr by remember(currentSettings) { mutableStateOf(currentSettings.co2DefaultConcentration.toString()) }
    var igConcStr by remember(currentSettings) { mutableStateOf(currentSettings.ig541DefaultConcentration.toString()) }
    var gstStr by remember(currentSettings) { mutableStateOf(currentSettings.defaultGstPercentage.toString()) }

    var co2RateStr by remember(currentSettings) { mutableStateOf(currentSettings.defaultCo2RatePerKg.toString()) }
    var igRateStr by remember(currentSettings) { mutableStateOf(currentSettings.defaultIg541RatePerM3.toString()) }
    var cylRateStr by remember(currentSettings) { mutableStateOf(currentSettings.defaultCylinderRate.toString()) }
    var nozzleRateStr by remember(currentSettings) { mutableStateOf(currentSettings.defaultNozzleRate.toString()) }
    var pipeRateStr by remember(currentSettings) { mutableStateOf(currentSettings.defaultPipeRatePerMtr.toString()) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("System Parameters & Equipment Cost Config", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }

        // Section 1: Gas System Default Parameters
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Gas System Default Parameters", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = co2CapStr,
                            onValueChange = { co2CapStr = it },
                            label = { Text("CO₂ Cylinder Capacity (kg)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = co2ConcStr,
                            onValueChange = { co2ConcStr = it },
                            label = { Text("CO₂ Default Conc. (%)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = igVolStr,
                            onValueChange = { igVolStr = it },
                            label = { Text("IG-541 Cylinder Vol (Liters)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = igPressStr,
                            onValueChange = { igPressStr = it },
                            label = { Text("IG-541 Pressure (Bar)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = igConcStr,
                            onValueChange = { igConcStr = it },
                            label = { Text("IG-541 Default Conc. (%)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = gstStr,
                            onValueChange = { gstStr = it },
                            label = { Text("Default GST Tax (%)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                }
            }
        }

        // Section 2: Default Commercial Equipment Rates
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Default Commercial Rates ($)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = co2RateStr,
                            onValueChange = { co2RateStr = it },
                            label = { Text("CO₂ Agent Rate ($/kg)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = igRateStr,
                            onValueChange = { igRateStr = it },
                            label = { Text("IG-541 Gas Rate ($/m³)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = cylRateStr,
                            onValueChange = { cylRateStr = it },
                            label = { Text("Cylinder Assembly ($/No)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = nozzleRateStr,
                            onValueChange = { nozzleRateStr = it },
                            label = { Text("Nozzle Rate ($/No)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }

                    OutlinedTextField(
                        value = pipeRateStr,
                        onValueChange = { pipeRateStr = it },
                        label = { Text("Seamless SCH 80 Pipe Rate ($/Mtr)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            }
        }

        // Save Action
        item {
            Button(
                onClick = {
                    val updated = SettingsEntity(
                        id = 1,
                        co2CylinderCapacityKg = co2CapStr.toDoubleOrNull() ?: 45.0,
                        ig541CylinderVolumeLiters = igVolStr.toDoubleOrNull() ?: 80.0,
                        ig541CylinderPressureBar = igPressStr.toIntOrNull() ?: 200,
                        co2DefaultConcentration = co2ConcStr.toDoubleOrNull() ?: 50.0,
                        ig541DefaultConcentration = igConcStr.toDoubleOrNull() ?: 38.0,
                        defaultGstPercentage = gstStr.toDoubleOrNull() ?: 18.0,
                        defaultCo2RatePerKg = co2RateStr.toDoubleOrNull() ?: 12.0,
                        defaultIg541RatePerM3 = igRateStr.toDoubleOrNull() ?: 18.0,
                        defaultCylinderRate = cylRateStr.toDoubleOrNull() ?: 450.0,
                        defaultNozzleRate = nozzleRateStr.toDoubleOrNull() ?: 65.0,
                        defaultPipeRatePerMtr = pipeRateStr.toDoubleOrNull() ?: 35.0
                    )
                    viewModel.saveSettings(updated)
                    Toast.makeText(context, "System parameters saved persistently!", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Save, contentDescription = "Save Settings")
                Spacer(modifier = Modifier.width(6.dp))
                Text("Save Configuration")
            }
        }

        item {
            EngineeringDisclaimerCard()
        }
    }
}
