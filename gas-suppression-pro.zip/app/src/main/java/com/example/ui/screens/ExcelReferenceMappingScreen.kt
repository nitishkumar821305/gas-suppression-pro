package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.calculations.CO2Engine
import com.example.calculations.IG541Engine
import com.example.ui.components.EngineeringDisclaimerCard

data class ExcelAnnexureMap(
    val annexureName: String,
    val targetSystem: String,
    val calculationType: String,
    val excelSheetReference: String,
    val softwareModule: String
)

data class TestScenario(
    val id: String,
    val roomName: String,
    val systemType: String, // "CO2" or "IG541"
    val length: Double,
    val width: Double,
    val height: Double,
    val excelExpectedGas: Double,
    val excelExpectedCylinders: Int,
    val excelExpectedNozzles: Int
)

@Composable
fun ExcelReferenceMappingScreen(
    onNavigate: (String) -> Unit
) {
    var activeTab by remember { mutableIntStateOf(0) }

    val annexures = listOf(
        ExcelAnnexureMap("ANNEXURE 1", "IG-541 Inergen", "Volumetric Gas Agent & Pressure Design", "Sheet: ANNEXURE 1 (IG-541 Design)", "IG541Engine.kt"),
        ExcelAnnexureMap("ANNEXURE 2", "IG-541 Inergen", "Automatic BOQ Item & Accessories Sizing", "Sheet: ANNEXURE 2 (IG-541 BOQ)", "BOQEngine.kt (IG-541 Mapping)"),
        ExcelAnnexureMap("ANNEXURE 3", "CO₂ Total Flooding", "Generator Room Hazard Calculation", "Sheet: ANNEXURE 3 (CO2 Gen Design)", "CO2Engine.kt (Deep Seated / Generator)"),
        ExcelAnnexureMap("ANNEXURE 4", "CO₂ Total Flooding", "Generator Room Equipment BOQ", "Sheet: ANNEXURE 4 (CO2 Gen BOQ)", "BOQEngine.kt (CO2 Generator Mapping)"),
        ExcelAnnexureMap("ANNEXURE 5", "CO₂ Total Flooding", "Control & Electrical Room Calculation", "Sheet: ANNEXURE 5 (CO2 Control Design)", "CO2Engine.kt (Electrical Hazard)"),
        ExcelAnnexureMap("ANNEXURE 6", "CO₂ Total Flooding", "Control Room Equipment BOQ", "Sheet: ANNEXURE 6 (CO2 Control BOQ)", "BOQEngine.kt (CO2 Control Mapping)")
    )

    val testScenarios = listOf(
        TestScenario("TC-01", "Small Control Room (CO₂)", "CO2", 6.0, 5.0, 3.0, 102.3, 3, 2),
        TestScenario("TC-02", "Medium Control Room (CO₂)", "CO2", 10.0, 8.0, 4.0, 365.1, 9, 4),
        TestScenario("TC-03", "Large Electrical Substation (CO₂)", "CO2", 15.0, 10.0, 5.0, 856.2, 20, 6),
        TestScenario("TC-04", "Battery Room (IG-541 200 bar)", "IG541", 12.0, 6.0, 3.5, 154.2, 11, 3),
        TestScenario("TC-05", "Server Facility (IG-541 300 bar)", "IG541", 18.0, 10.0, 4.5, 495.8, 24, 6)
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Excel Reference Mapping & Verification Test Mode",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )

        TabRow(selectedTabIndex = activeTab) {
            Tab(selected = activeTab == 0, onClick = { activeTab = 0 }) {
                Text("Workbook Structure Mapping", modifier = Modifier.padding(12.dp), fontWeight = FontWeight.Bold)
            }
            Tab(selected = activeTab == 1, onClick = { activeTab = 1 }) {
                Text("Software vs Excel Verification Test", modifier = Modifier.padding(12.dp), fontWeight = FontWeight.Bold)
            }
        }

        if (activeTab == 0) {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(annexures) { map ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = map.annexureName,
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                    )
                                }
                                SuggestionChip(
                                    onClick = {},
                                    label = { Text(map.targetSystem, fontSize = 11.sp) }
                                )
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Text(map.calculationType, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Workbook Source: ${map.excelSheetReference}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                            Text("Engine Implementation: ${map.softwareModule}", style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        } else {
            // Software vs Excel Test Mode
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(testScenarios) { tc ->
                    val (calcGas, calcCyls, calcNozzles) = if (tc.systemType == "CO2") {
                        val res = CO2Engine.calculate(tc.length, tc.width, tc.height)
                        Triple(res.totalProvidedGasKg, res.cylinderCount, res.nozzleCount)
                    } else {
                        val res = IG541Engine.calculate(tc.length, tc.width, tc.height)
                        Triple(res.requiredGasM3, res.cylinderCount, res.nozzleCount)
                    }

                    val passCylinders = calcCyls == tc.excelExpectedCylinders
                    val passNozzles = calcNozzles == tc.excelExpectedNozzles
                    val isPass = passCylinders && passNozzles

                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isPass) MaterialTheme.colorScheme.surface
                            else MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.2f)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("${tc.id}: ${tc.roomName}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                    Text("Dimensions: ${tc.length} × ${tc.width} × ${tc.height} m (${tc.length * tc.width * tc.height} m³)", style = MaterialTheme.typography.bodySmall)
                                }
                                Surface(
                                    color = if (isPass) Color(0xFF10B981) else MaterialTheme.colorScheme.error,
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = if (isPass) "PASS (MATCH)" else "FAIL / DIFF",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Divider()
                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("Excel Ref Cylinders: ${tc.excelExpectedCylinders}", style = MaterialTheme.typography.bodySmall)
                                    Text("Software Cylinders: $calcCyls", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                                }
                                Column {
                                    Text("Excel Ref Nozzles: ${tc.excelExpectedNozzles}", style = MaterialTheme.typography.bodySmall)
                                    Text("Software Nozzles: $calcNozzles", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                                }
                                Column {
                                    Text("Calculated Agent:", style = MaterialTheme.typography.bodySmall)
                                    Text("${String.format("%.1f", calcGas)} ${if (tc.systemType == "CO2") "kg" else "m³"}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    }
                }
            }
        }

        EngineeringDisclaimerCard()
    }
}
