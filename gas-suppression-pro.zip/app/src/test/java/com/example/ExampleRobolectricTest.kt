package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.calculations.CO2Engine
import com.example.calculations.IG541Engine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Gas Suppression Pro", appName)
    }

    @Test
    fun `test CO2 calculation engine`() {
        val res = CO2Engine.calculate(length = 10.0, width = 8.0, height = 4.0, unit = "metre")
        assertEquals(320.0, res.roomVolumeM3, 0.01)
        assertTrue(res.cylinderCount >= 8)
        assertTrue(res.nozzleCount >= 4)
    }

    @Test
    fun `test IG541 calculation engine`() {
        val res = IG541Engine.calculate(length = 12.0, width = 6.0, height = 3.5, unit = "metre")
        assertEquals(252.0, res.roomVolumeM3, 0.01)
        assertTrue(res.cylinderCount >= 10)
        assertTrue(res.nozzleCount >= 3)
    }
}
